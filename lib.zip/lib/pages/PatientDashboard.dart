import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/DailyActivities.dart';
import 'package:satyak_app/pages/DietChart.dart';
import 'package:satyak_app/pages/DoctorAssessment.dart';
import 'package:satyak_app/pages/MedicalReport.dart';
import 'package:satyak_app/pages/MedicineChart.dart';
import 'package:satyak_app/pages/NurseAssessment.dart';
import 'package:satyak_app/pages/PhotoGallery.dart';
import 'package:satyak_app/pages/SensoryAssessment.dart';

class PatientDashboard extends StatefulWidget {
  @override
  _PatientDashboardState createState() => _PatientDashboardState();
}

class _PatientDashboardState extends State<PatientDashboard> {
  final PatientData patientData = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              Image.asset(
                'images/Rutuja.jpg',
                height: 300,
                width: 300,
              ),
              Text(
                "PHN: ${patientData.patientHealthNumber}",
                style: TextStyle(fontSize: 22),
              ),
              Text(
                patientData.patientName,
                style: TextStyle(fontSize: 22),
              ),
              Text(
                "Age: ${patientData.patientAge}",
                style: TextStyle(fontSize: 22),
              ),
              SizedBox(height: 10),
              Row(
                children: [
                  CupertinoButton(
                      color: Colors.teal[400],
                      padding:
                          const EdgeInsets.fromLTRB(60.0, 34.0, 60.0, 34.0),
                      child: Text(
                        "Nurse \nAssessment",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => NurseAssessment()));
                      }),
                  CupertinoButton(
                      color: Colors.teal[500],
                      padding:
                          const EdgeInsets.fromLTRB(60.0, 34.0, 50.0, 34.0),
                      child: Text(
                        "Doctor \nAssessment",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => DoctorAssessment()));
                      }),
                ],
              ),
              Row(
                children: [
                  CupertinoButton(
                      color: Colors.teal[500],
                      padding:
                          const EdgeInsets.fromLTRB(72.0, 34.0, 72.0, 34.0),
                      child: Text(
                        "Daily \nActivities",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => DailyActivities()));
                      }),
                  CupertinoButton(
                      color: Colors.teal[400],
                      padding:
                          const EdgeInsets.fromLTRB(60.0, 34.0, 51.0, 34.0),
                      child: Text(
                        "Sensory \nAssessment",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => SensoryAssessment()));
                      }),
                ],
              ),
              Row(
                children: [
                  CupertinoButton(
                      color: Colors.teal[400],
                      padding:
                          const EdgeInsets.fromLTRB(70.0, 34.0, 70.0, 34.0),
                      child: Text(
                        "Medicine \nChart",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => MedicineChart()));
                      }),
                  CupertinoButton(
                      color: Colors.teal[500],
                      padding:
                          const EdgeInsets.fromLTRB(86.0, 34.0, 78.0, 34.0),
                      child: Text(
                        "Diet \nChart",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => DietChart()));
                      }),
                ],
              ),
              Row(
                children: [
                  CupertinoButton(
                      color: Colors.teal[500],
                      padding:
                          const EdgeInsets.fromLTRB(75.0, 32.0, 75.0, 32.0),
                      child: Text(
                        "Medical \nReport",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => MedicalReport()));
                      }),
                  CupertinoButton(
                      color: Colors.teal[400],
                      padding:
                          const EdgeInsets.fromLTRB(80.0, 32.0, 73.0, 32.0),
                      child: Text(
                        "Photo \nGallery",
                        style: TextStyle(fontSize: 18),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => PhotoGallery()));
                      }),
                ],
              ),
              SizedBox(
                height: 10.0,
              )
            ],
          ),
        ));
  }
}
