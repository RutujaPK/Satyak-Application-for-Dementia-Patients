import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/pages/GuardianRegister.dart';
import 'package:satyak_app/pages/InHouseDocRegister.dart';
import 'package:satyak_app/pages/NurseRegister.dart';
import 'package:satyak_app/pages/VisitDocRegister.dart';
//import 'package:lottie/lottie.dart';
//import 'package:satyak_app/pages/homePage.dart';

class SelectUser extends StatefulWidget {
  @override
  _SelectUserState createState() => _SelectUserState();
}

class _SelectUserState extends State<SelectUser> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Column(children: [
            SizedBox(height: 50.0),
            Container(
              child: Align(
                alignment: Alignment.topCenter,
                child: Text(
                  "Register as:",
                  style: TextStyle(
                      fontSize: 30,
                      color: Colors.teal[600],
                      fontWeight: FontWeight.w300),
                ),
              ),
            ),
            SizedBox(height: 80.0),
            Align(
              alignment: Alignment.topCenter,
              child: CupertinoButton(
                  color: Colors.teal[400],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      "  In-House Doctor  ",
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => InHouseDocRegister(
                                registerType: "InHouseDoctor")));
                  }),
            ),
            SizedBox(height: 50.0),
            Align(
              alignment: Alignment.topCenter,
              child: CupertinoButton(
                  color: Colors.teal[300],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      "           Nurse           ",
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) =>
                                NurseRegister(registerType: "Nurse")));
                  }),
            ),
            SizedBox(height: 50.0),
            Align(
              alignment: Alignment.topCenter,
              child: CupertinoButton(
                  color: Colors.teal[400],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      "    Visitor Doctor    ",
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => VisitDocRegister(
                                registerType: "VisitorDoctor")));
                  }),
            ),
            SizedBox(height: 50.0),
            Align(
              alignment: Alignment.topCenter,
              child: CupertinoButton(
                  color: Colors.teal[300],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      "      Guardian      ",
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) =>
                                GuardianRegister(registerType: "Guardian")));
                  }),
            )
          ]),
        ));
  }
}
