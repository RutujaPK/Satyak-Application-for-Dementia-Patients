import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:lottie/lottie.dart';
import 'package:satyak_app/pages/loginPage.dart';

class HomePage3 extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage3> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.teal[100],
      appBar: AppBar(
        backgroundColor: Colors.teal[400],
        elevation: 0.0,
        title: Text(
          "SATYAK",
          style: TextStyle(fontSize: 30.0),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          SizedBox(height: 50.0),
          Container(
            height: MediaQuery.of(context).size.height / 3,
            width: MediaQuery.of(context).size.width,
            child: Lottie.asset("images/Facilities_Homepage3.json"),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
                child: Text(
              "Services and Facilities available at Satyak",
              style: TextStyle(
                  fontSize: 30,
                  color: Colors.teal[600],
                  fontWeight: FontWeight.w500),
            )),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
                child: Text(
              "1. Continuous Care \n2. Dementia Care \n3.Respite Care \n4. Pallative Care \n5.Nursing \n6.Attendant \n7.Physiotherapist \n8.Doctors Visit \n9.Structured Daily Activities \n10.Friendly Infrastructure ",
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.teal[400],
                  fontWeight: FontWeight.w500),
            )),
          ),
          Container(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 0.0, 0.0, 50.0),
                child: Align(
                    alignment: Alignment.bottomRight,
                    child: TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => LoginPage()));
                        },
                        child: Text(
                          "Login",
                          style: TextStyle(fontSize: 25),
                        ))),
              )
            ],
          )),
        ]),
      ),
    );
  }
}
