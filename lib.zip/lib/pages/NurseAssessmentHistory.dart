import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/NurseAssessment.dart';
import 'package:satyak_app/models/PatientData.dart';

class NurseAssessmentHistory extends StatefulWidget {
  @override
  _NurseAssessmentHistoryState createState() => _NurseAssessmentHistoryState();
}

class _NurseAssessmentHistoryState extends State<NurseAssessmentHistory> {
  final PatientData patientData = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: null,
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('patients')
              .doc(patientData.documentId)
              .collection("NurseAssessment")
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            return Container(
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 40.0, 0.0, 0),
                    child: DataTable(
                        columns: [
                          DataColumn(label: Text('Date')),
                          DataColumn(label: Text('Blood Pressure')),
                          DataColumn(label: Text('Pulse')),
                          DataColumn(label: Text('Weight')),
                        ],
                        columnSpacing: 10.0,
                        rows: _buildList(snapshot.data.docs))));
          }),
    );
  }

  List<DataRow> _buildList(List<DocumentSnapshot> snapshot) {
    return snapshot.map((data) => _buildListItem(data)).toList();
  }

  DataRow _buildListItem(DocumentSnapshot document) {
    final nurseAssessmentData =
        NurseAssessmentData.fromJson(document.data(), document.id);

    return DataRow(cells: [
      DataCell(Text(nurseAssessmentData.nurseAssessmentDate)),
      DataCell(Text(nurseAssessmentData.nurseAssessmentBloodPressure)),
      DataCell(Text(nurseAssessmentData.nurseAssessmentPulse)),
      DataCell(Text(nurseAssessmentData.nurseAssessmentWeight)),
    ]);
  }
}
