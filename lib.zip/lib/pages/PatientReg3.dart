import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/PatientReg4.dart';

//import 'package:satyak_app/pages/PatientReg5.dart';
import 'dart:developer' as developer;

class PatientReg3 extends StatefulWidget {
  @override
  _PatientReg3State createState() => _PatientReg3State();
}

class _PatientReg3State extends State<PatientReg3> {
  TextEditingController applicantGuardianNameController;
  TextEditingController patientNameController;
  TextEditingController applicantGuardianRelationWithPatientController;
  TextEditingController patientIssueController;
  TextEditingController legalGuardianNameController;
  TextEditingController legalGuardianRelationWithPatientController;
  TextEditingController applicationDateController;
  TextEditingController applicationPlaceController;
  TextEditingController legalGuardianApplicationDateController;
  TextEditingController legalGuardianApplicationPlaceController;
  TextEditingController applicantGuardianNameController2;
  DateTime currentDate = DateTime.now();
  var patientData = PatientData.instance;

  @override
  initState() {
    applicantGuardianNameController = new TextEditingController();
    patientNameController =
        new TextEditingController(text: patientData.patientName);
    applicantGuardianRelationWithPatientController =
        new TextEditingController();
    patientIssueController = new TextEditingController();
    legalGuardianNameController =
        new TextEditingController(text: patientData.legalGuardianName);
    legalGuardianRelationWithPatientController = new TextEditingController();
    applicationDateController = new TextEditingController();
    applicationPlaceController = new TextEditingController();
    legalGuardianApplicationDateController = new TextEditingController();
    legalGuardianApplicationPlaceController = new TextEditingController();
    applicantGuardianNameController2 = new TextEditingController();
    super.initState();
  }

  Future<void> _selectApplicationDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        applicationDateController.text = date;
      });
  }

  Future<void> _selectLegalGuardianApplicationDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        legalGuardianApplicationDateController.text = date;
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Container(
                child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                  child: Column(children: [
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 20.0),
                                  child: Text(
                                    " C. Declaration of Understanding and Acceptance of the Conditions pertaining to the Admission for a Residential stay at Satyak Assisted Living, Pune",
                                    style: TextStyle(
                                        fontSize: 23,
                                        color: Colors.teal[600],
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "I Mr./Mrs.",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  controller: applicantGuardianNameController,
                                  onChanged: (text) {
                                    setState(() {
                                      applicantGuardianNameController2.text =
                                          text;
                                    });
                                  },
                                  decoration: InputDecoration(
                                      labelText: "Guardian Name"),
                                ),
                                SizedBox(height: 20),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "on the behalf of and for",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  readOnly: true,
                                  controller: patientNameController,
                                  decoration: InputDecoration(
                                      labelText: "Patient Name"),
                                ),
                                SizedBox(height: 20),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "as the",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  controller:
                                      applicantGuardianRelationWithPatientController,
                                  decoration: InputDecoration(
                                      labelText: "Relationship with Patient"),
                                ),
                                SizedBox(height: 20),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "do declare and affirm as follows:\n\n1. I am applying for and on the behalf of Mr./Mrs.",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  readOnly: true,
                                  controller: patientNameController,
                                  decoration: InputDecoration(
                                      labelText: "Patient Name"),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "to admit him/her for the residential stay at Satyak Assisted Living, Pune for psycho social rehabilitation as he/she is suffering from ",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  controller: patientIssueController,
                                  decoration: InputDecoration(
                                      labelText: "Mention the issue"),
                                ),
                                SizedBox(height: 20),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "2. I am informed of, and am hereby ready to take the financial responsibility for monthly fee which will cover the cost of accomodation, food and other necessary psycho-sociol-interventions such as individual counselling, group therapy, family therapy, personal hygiene supervision, art therapy.\n\n3. However the following will be additional expenses:\nMedicine\nGeneral consultation (if required)\nGeneral Pathological tests (Haemogram with ESR, Urine routine, Blood-sugar, Blood Urea, Serum TSH, Serum Creatinine)\nX-Ray\nMRI\nCT-Scan\n\n",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "The following tests are mandatory for all patients on admission: Haemogram, LFT, KFT, TFT, SR Electrolyte, Serum cholestrol, Bloof Sugar(Fasting and Post Prandial), HbA1C(if Diabetic), VDRL, Urine(Routine/Microscopy), ECG. These test will be repeated at 6 months interval as per care protocols. \n\nIf the patient has dementia, baseline evaluation will be done by the Neuropsychologist on admission and at 6 month interval.\n\nAll the personal expenditures such as soap/oil/toothpaste or any other personal articles\n\nAny eatables or special diet given other than common food provided\n\nPicnic, Movies, Lunchouts, etc\n\nSpecial Attendant will not be included in the fees\n\n4. If incase of hospitalization, I promise to bear the expenses incurred in the hospital and at Satyak Assisted Living shall not be held responsible for the same.\n\n5. The monthly fees and expenditure should be paid on or before the 7th day of every month. Incase of delay in the payment, Satyak Assisted Living, Pune, will reserve the right and discretion to discharge the patieny.\n\n6. I understand that the fees are charged on a monthly basis and the same will not be refunded under any circumstances.\n\n7. If I do not comply with the above mentioned financial responsibility, Satyak Assisted Living, Pune, will reserve the right to take legal action.\n\n8. The fact that the patient is temporarily in the care of Satyak Assisted Living, Pune, it offers no protection in law, criminal acts including attempted or actual suicide while as a patient and are subject to legal action and Satyak Assisted Living, Pune accepts no responsibilty in this connection.\n\n9. I do understand that wandering tendencies, absconding, suicidal tendencies, biolent behaviours, suspiciousness, etc. are some of the symptoms of mental illness. If any such incident occurs, I will not hold Satyak Assisted Living, Pune, responsible.\n\n10. I understand that although the patient is under the care of Satyak Assisted Living, Pune, there could be some unfortunate incidents such as accidents of any kind, fracture due to fall or while walking, bed sores due to immobility, any kind of illness which can result in emergency or death of the patient, I will not hold Satyak Assisted Living, Pune, responsible for the same.\n\n11. I have been informed that all the medicines have side effects and so I will not hold Satyak Assisted Living, Pune, liable for the same.\n\n12. I agree to follow the rules and regulations laid down by Satyak Assisted Living, Pune, for the relatives of the patient. If I violate any rules, Satyak Assisted Living, Pune, can take legal action against me.\n\n13. Satyak Assisted Living, Pune, is an independent organization. Satyak Assisted Living, Pune, shall not be responsible for any treatment taken anywhere by the resident before enrolling at Satyak Assisted Living, Pune or after discharge.\n\n14. Counsellor from outside or other agencies will not be permitted to facilitate any session with the patients. \n\n15. Any disputes arising out of this agreement will be subjected to jurisdiction of the Pune court only.\n\n16. I declare that I have given all the information about the patient that is crucial and important for his/her proper treatment. The information that I have given is true to the best of my knowledge and I have not concealed any vital information. If at any later stage the staff of Satyak Assisted Living, Pune, undertands that some vital information was concealed. They reserve all the right to take legal action.\n\nI,   ",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  readOnly: true,
                                  controller: legalGuardianNameController,
                                  decoration: InputDecoration(
                                      labelText: "Guardian's Name"),
                                ),
                                SizedBox(height: 20),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "declare that the above mentioned information has been explained to me in the language that I understand. I accept the conditions and hereby confirm to comply by my responsibilities as a ",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  controller:
                                      legalGuardianRelationWithPatientController,
                                  decoration: InputDecoration(
                                      labelText:
                                          "Relationship with the Patient"),
                                ),
                                SizedBox(height: 20),
                                Align(
                                  alignment: Alignment.topLeft,
                                  child: Text(
                                    "and hence I give my free and informed consent to the same.",
                                    style: TextStyle(
                                        fontSize: 15,
                                        color: Colors.teal[1000],
                                        fontWeight: FontWeight.w300),
                                  ),
                                ),
                                TextFormField(
                                  decoration: InputDecoration(
                                    labelText:
                                        "Electronic Signature of Applicant",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                TextFormField(
                                  controller: applicantGuardianNameController,
                                  decoration: InputDecoration(
                                    labelText: "Name of Applicant",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                TextFormField(
                                  readOnly: true,
                                  onTap: () {
                                    // Below line stops keyboard from appearing
                                    FocusScope.of(context)
                                        .requestFocus(new FocusNode());

                                    // Show Date Picker Here
                                    _selectApplicationDate(context);
                                  },
                                  controller: applicationDateController,
                                  decoration: InputDecoration(
                                    labelText: "Date",
                                    hintText: "DD/MM/YYY",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                TextFormField(
                                  controller: applicationPlaceController,
                                  decoration: InputDecoration(
                                    labelText: "Place",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                TextFormField(
                                  decoration: InputDecoration(
                                    labelText:
                                        "Electronic Signature of Legal Guardian",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                TextFormField(
                                  controller: legalGuardianNameController,
                                  decoration: InputDecoration(
                                    labelText: "Name of Legal Guardian",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                TextFormField(
                                  readOnly: true,
                                  onTap: () {
                                    // Below line stops keyboard from appearing
                                    FocusScope.of(context)
                                        .requestFocus(new FocusNode());

                                    // Show Date Picker Here
                                    _selectLegalGuardianApplicationDate(
                                        context);
                                  },
                                  controller:
                                      legalGuardianApplicationDateController,
                                  decoration: InputDecoration(
                                    labelText: "Date",
                                    hintText: "DD/MM/YYY",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                TextFormField(
                                  controller:
                                      legalGuardianApplicationPlaceController,
                                  decoration: InputDecoration(
                                    labelText: "Place",
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: CupertinoButton(
                                      color: Colors.teal[400],
                                      borderRadius: BorderRadius.circular(50.0),
                                      child: Text(
                                        "         Next         ",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      onPressed: () {
                                        patientData.applicantGuardianName =
                                            applicantGuardianNameController
                                                .text;
                                        patientData
                                                .applicantRelationWithPatient =
                                            applicantGuardianRelationWithPatientController
                                                .text;
                                        patientData.applicantPatientIssue =
                                            patientIssueController.text;
                                        patientData.legalGuardianName =
                                            legalGuardianNameController
                                                .text;
                                        patientData
                                                .legalGuardianRelationWithPatient =
                                            applicantGuardianRelationWithPatientController
                                                .text;
                                        patientData.applicationDate =
                                            applicationDateController.text;
                                        patientData.applicationLocation =
                                            applicationPlaceController.text;
                                        patientData
                                                .legalGuardianApplicationDate =
                                            legalGuardianApplicationDateController
                                                .text;
                                        patientData
                                                .legalGuardianApplicationLocation =
                                            legalGuardianApplicationPlaceController
                                                .text;

                                        Navigator.push(
                                            context,
                                            CupertinoPageRoute(
                                                builder: (context) =>
                                                    PatientReg4()));
                                      }),
                                )
                              ]))))
                    ])))));
  }
}
