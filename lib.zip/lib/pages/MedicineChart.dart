import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satyak_app/models/MedicineChart.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/MedicineChartHistory.dart';

class MedicineChart extends StatefulWidget {
  @override
  _MedicineChartState createState() => _MedicineChartState();
}

class _MedicineChartState extends State<MedicineChart> {
  TextEditingController dateInputController;
  TextEditingController docInputController;
  TextEditingController medInputController;
  TextEditingController freqInputController;
  TextEditingController instructionInputController;
  final PatientData patientData = FirebaseData.patientData;
  DateTime currentDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dateInputController.text = date;
      });
  }

  @override
  initState() {
    dateInputController = new TextEditingController();
    docInputController = new TextEditingController();
    medInputController = new TextEditingController();
    freqInputController = new TextEditingController();
    instructionInputController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "Medicine Chart",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              onTap: () {
                                // Below line stops keyboard from appearing
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());

                                // Show Date Picker Here
                                _selectDate(context);
                              },
                              controller: dateInputController,
                              decoration: InputDecoration(
                                  labelText: "Date",
                                  hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: docInputController,
                              decoration: InputDecoration(
                                  labelText: "Doctor's Name",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: medInputController,
                              decoration: InputDecoration(
                                  labelText: "Prescribed Medicine",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: freqInputController,
                              decoration: InputDecoration(
                                  labelText: "Frequency",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: instructionInputController,
                              decoration: InputDecoration(
                                  labelText: "Instructions / Comments",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Text(
                                      "         Save         ",
                                      style: TextStyle(fontSize: 20),
                                    ),
                                    onPressed: () {
                                      saveMedicineChartData();
                                    })),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0.0, 15.0, 0.0),
                                      child: Text(
                                        "View History",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                    ),
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          CupertinoPageRoute(
                                              builder: (context) =>
                                                  MedicineChartHistory()));
                                    }))
                          ]))))
                ]))));
  }

  void saveMedicineChartData() {
    MedicineData medicineData = new MedicineData(
        medicineDataDate: dateInputController.text,
        medicineDataDoc: docInputController.text,
        medicineDataMed: medInputController.text,
        medicineDataFreq: freqInputController.text,
        medicineDataInstructions: instructionInputController.text);

    FirebaseFirestore.instance
        .collection('patients')
        .doc(patientData.documentId)
        .collection("MedicineChart")
        .add(medicineData.toJson())
        .then((data) => {print("Medicine data added ${medicineData.toJson()}")})
        .catchError((err) => print(err));
  }
}
