import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:lottie/lottie.dart';
import 'package:satyak_app/pages/homePage2.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.teal[100],
      appBar: AppBar(
        backgroundColor: Colors.teal[400],
        elevation: 0.0,
        title: Text(
          "SATYAK",
          style: TextStyle(fontSize: 30.0),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          SizedBox(height: 50.0),
          Container(
            height: MediaQuery.of(context).size.height / 3,
            width: MediaQuery.of(context).size.width,
            child: Lottie.asset("images/Intro_HomePage1.json"),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
                child: Text(
              "What is Dementia ?",
              style: TextStyle(
                  fontSize: 30,
                  color: Colors.teal[600],
                  fontWeight: FontWeight.w500),
            )),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
                child: Text(
              "Dementia is a collective term used to describe various symptoms of cognitive decline, such as forgetfulness. It is a symptom of several underlying diseases and brain disorders. \n\nDementia is not a single disease in itself, but a general term to describe symptoms of impairment in memory, communication, and thinking.\n\n\n",
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.teal[400],
                  fontWeight: FontWeight.w500),
            )),
          ),
          Container(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 0.0, 0.0, 50.0),
                child: Align(
                    alignment: Alignment.bottomRight,
                    child: TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => HomePage2()));
                        },
                        child: Text(
                          "Next",
                          style: TextStyle(fontSize: 25),
                        ))),
              )
            ],
          )),
        ]),
      ),
    );
  }
}
