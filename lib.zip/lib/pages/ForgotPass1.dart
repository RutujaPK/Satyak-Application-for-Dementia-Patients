import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/pages/ForgotPass2.dart';
import 'dart:developer' as developer;

class ForgotPass1 extends StatefulWidget {
  @override
  _ForgotPass1State createState() => _ForgotPass1State();
}

class _ForgotPass1State extends State<ForgotPass1> {
  TextEditingController resetPasswordEmailController;
  @override
  initState() {
    resetPasswordEmailController = new TextEditingController();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          SizedBox(height: 50.0),
          Container(
            child: Center(
                child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                "Enter your Registered Email Id: ",
                style: TextStyle(
                    fontSize: 25,
                    color: Colors.teal[600],
                    fontWeight: FontWeight.w500),
              ),
            )),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextFormField(
              controller: resetPasswordEmailController,
              decoration: InputDecoration(
                labelText: "Email Id",
              ),
            ),
          ),
          SizedBox(height: 30.0),
          CupertinoButton(
              color: Colors.teal[400],
              borderRadius: BorderRadius.circular(50.0),
              child: Text(
                "       Submit      ",
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                FirebaseAuth.instance.
                sendPasswordResetEmail(email: resetPasswordEmailController.text.toString())
                    .then((result)=> {
                    // Email sent.
                developer.log('email sent to user')
                }).catchError((err) => print(err));
              }),
          SizedBox(height: 50.0),
          SizedBox(height: 50.0),
          Container(
              child: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Text(
              "Enter OTP: ",
              style: TextStyle(
                  fontSize: 25,
                  color: Colors.teal[600],
                  fontWeight: FontWeight.w500),
            ),
          )),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextFormField(
              decoration: InputDecoration(
                labelText: "OTP",
              ),
            ),
          ),
          SizedBox(height: 50.0),
          CupertinoButton(
              color: Colors.teal[400],
              borderRadius: BorderRadius.circular(50.0),
              child: Text(
                "      Verify      ",
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                Navigator.push(context,
                    CupertinoPageRoute(builder: (context) => ForgotPass2()));
              }),
        ])));
  }
}
