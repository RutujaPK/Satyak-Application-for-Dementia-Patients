import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/NurseAssessment.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/NurseAssessmentHistory.dart';

class NurseAssessment extends StatefulWidget {
  @override
  _NurseAssessmentState createState() => _NurseAssessmentState();
}

class _NurseAssessmentState extends State<NurseAssessment> {
  TextEditingController dateInputController;
  TextEditingController pulseInputController;
  TextEditingController bloodPressureInputController;
  TextEditingController weightInputController;
  final PatientData patientData = FirebaseData.patientData;
  DateTime currentDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dateInputController.text = date;
      });
  }

  @override
  initState() {
    dateInputController = new TextEditingController();
    pulseInputController = new TextEditingController();
    bloodPressureInputController = new TextEditingController();
    weightInputController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "Nurse Assessment",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              onTap: () {
                                // Below line stops keyboard from appearing
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());

                                // Show Date Picker Here
                                _selectDate(context);
                              },
                              controller: dateInputController,
                              decoration: InputDecoration(
                                  labelText: "Date",
                                  hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: pulseInputController,
                              decoration: InputDecoration(
                                  labelText: "Pulse",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: bloodPressureInputController,
                              decoration: InputDecoration(
                                  labelText: "Blood Pressure",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: weightInputController,
                              decoration: InputDecoration(
                                  labelText: "Weight",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Text(
                                      "     Save Data     ",
                                      style: TextStyle(fontSize: 20),
                                    ),
                                    onPressed: () {
                                      saveNurseAssessmentData();
                                    })),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Text(
                                      "   View History   ",
                                      style: TextStyle(fontSize: 20),
                                    ),
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          CupertinoPageRoute(
                                              builder: (context) =>
                                                  NurseAssessmentHistory()));
                                    }))
                          ]))))
                ]))));
  }

  void saveNurseAssessmentData() {
    NurseAssessmentData nurseAssessment = new NurseAssessmentData(
        nurseAssessmentDate: dateInputController.text,
        nurseAssessmentBloodPressure: bloodPressureInputController.text,
        nurseAssessmentPulse: pulseInputController.text,
        nurseAssessmentWeight: weightInputController.text);
    FirebaseFirestore.instance
        .collection('patients')
        .doc(patientData.documentId)
        .collection("NurseAssessment")
        .add(nurseAssessment.toJson())
        .then((data) =>
            {print("Nurse assement data added ${nurseAssessment.toJson()}")})
        .catchError((err) => print(err));
  }
}
