import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:lottie/lottie.dart';
import 'package:satyak_app/pages/homePage3.dart';

class HomePage2 extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.teal[100],
      appBar: AppBar(
        backgroundColor: Colors.teal[400],
        elevation: 0.0,
        title: Text(
          "SATYAK",
          style: TextStyle(fontSize: 30.0),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          SizedBox(height: 50.0),
          Container(
            height: MediaQuery.of(context).size.height / 3,
            width: MediaQuery.of(context).size.width,
            child: Lottie.asset("images/Doctor_Homepage2.json"),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
                child: Text(
              "Know our Doctors",
              style: TextStyle(
                  fontSize: 30,
                  color: Colors.teal[600],
                  fontWeight: FontWeight.w500),
            )),
          ),
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Container(
                child: Text(
              "Dr. Ninad Baste \nMBBS, MD(Psychological Medicine) \n\n Dr. Swati \n Medical Officer at Satyak  ",
              style: TextStyle(
                  fontSize: 20,
                  color: Colors.teal[400],
                  fontWeight: FontWeight.w500),
            )),
          ),
          SizedBox(height: 50.0),
          SizedBox(height: 50.0),
          SizedBox(height: 50.0),
          SizedBox(height: 30.0),
          Container(
              child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 0.0, 0.0, 50.0),
                child: Align(
                    alignment: Alignment.bottomRight,
                    child: TextButton(
                        onPressed: () {
                          Navigator.push(
                              context,
                              CupertinoPageRoute(
                                  builder: (context) => HomePage3()));
                        },
                        child: Text(
                          "Next ",
                          style: TextStyle(fontSize: 25),
                        ))),
              )
            ],
          )),
        ]),
      ),
    );
  }
}
