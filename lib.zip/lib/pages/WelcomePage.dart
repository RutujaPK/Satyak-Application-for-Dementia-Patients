import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/pages/ContactUs.dart';
//import 'package:lottie/lottie.dart';
import 'package:satyak_app/pages/homePage.dart';

class WelcomePage extends StatefulWidget {
  @override
  _WelcomePageState createState() => _WelcomePageState();
}

class _WelcomePageState extends State<WelcomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          SizedBox(height: 20.0),
          Container(
            child: Align(
              alignment: Alignment.topCenter,
              child: Text(
                "Welcome To",
                style: TextStyle(
                    fontSize: 40,
                    color: Colors.teal[600],
                    fontWeight: FontWeight.w300),
              ),
            ),
          ),
          SizedBox(height: 20.0),
          Container(
              child: Align(
            alignment: Alignment.topCenter,
            child: Text(
              "SATYAK",
              style: TextStyle(
                  fontSize: 80,
                  color: Colors.teal[600],
                  fontWeight: FontWeight.w600),
            ),
          )),
          SizedBox(height: 20.0),
          Container(
            child: Align(
              alignment: Alignment.topCenter,
              child: Text(
                "Assisted Living Center \nfor Dementia Patients",
                style: TextStyle(
                    fontSize: 30,
                    color: Colors.teal[600],
                    fontWeight: FontWeight.w300),
              ),
            ),
          ),
          SizedBox(height: 50.0),
          CupertinoButton(
              color: Colors.teal[400],
              borderRadius: BorderRadius.circular(50.0),
              child: Text(
                "   Contact Us   ",
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                Navigator.push(context,
                    CupertinoPageRoute(builder: (context) => ContactUs()));
              }),
          SizedBox(height: 20.0),
          Align(
              alignment: Alignment.bottomLeft,
              child: TextButton(
                  onPressed: () {
                    Navigator.push(context,
                        CupertinoPageRoute(builder: (context) => HomePage()));
                  },
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(20.0, 0.0, 0.0, 50.0),
                    child: Text(
                      "Next",
                      style: TextStyle(fontSize: 25),
                    ),
                  )))
        ])));
  }
}
