// Documents Upload Page
//
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/PatientReg5.dart';

class PatientReg4 extends StatefulWidget {
  @override
  _PatientReg4State createState() => _PatientReg4State();
}

class _PatientReg4State extends State<PatientReg4> {
  final PatientData patientObject = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: SingleChildScrollView(
                child: Padding(
                    padding: const EdgeInsets.all(20.0),
                    child: Column(children: [
                      Container(
                          width: MediaQuery.of(context).size.width,
                          child: Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                  child: Column(children: [
                                Padding(
                                  padding: const EdgeInsets.fromLTRB(
                                      0.0, 0.0, 0.0, 20.0),
                                  child: Text(
                                    " Documents ",
                                    style: TextStyle(
                                        fontSize: 25,
                                        color: Colors.teal[600],
                                        fontWeight: FontWeight.w500),
                                  ),
                                ),
                                SizedBox(
                                  height: 20.0,
                                ),
                                Text(
                                  "The form must be submitted along with the following documents which need to be submitted in the form of hardcopy as well as must be uploaded in the application profile. \n\n1. Passport size photos (2 copies, recent photos)\n\n2. Photo Identity Proof of the Patient (Aadhar card, PAN Card, Driving Liscense, Election Card or Passport)\n\n3. Address Proof for Permanent and Correspondence Address (Aadhar card, Driving Liscense, Passport, Ration Card, Electricity Bill, Telephone Bill)\n\n4. Age Proof (Aadhar card, Birth certificate, School Leaving Certificate, PAN Card, Driving Liscense, Election Card or Passport)",
                                  style: TextStyle(
                                      fontSize: 20,
                                      color: Colors.teal[1000],
                                      fontWeight: FontWeight.w300),
                                ),
                                SizedBox(
                                  height: 40,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: CupertinoButton(
                                      color: Colors.teal[400],
                                      borderRadius: BorderRadius.circular(50.0),
                                      child: Text(
                                        "       Upload       ",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      onPressed: () {
                                        getPdfAndUpload();
                                      }),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: CupertinoButton(
                                      color: Colors.teal[400],
                                      borderRadius: BorderRadius.circular(50.0),
                                      child: Text(
                                        "         Next         ",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            CupertinoPageRoute(
                                                builder: (context) =>
                                                    PatientReg5()));
                                      }),
                                )
                              ]))))
                    ])))));
  }
  Future getPdfAndUpload() async {
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile platformFile = result.files.single;
      File file = File(platformFile.path);
      // String fileName = '${randomName}.pdf';
      // print(fileName);
      // print('${file.readAsBytesSync()}');
      savePdf(file, platformFile.name);
    } else {
      // User canceled the picker
    }
  }

  Future savePdf(File asset, String fileName) async {
    Reference reference = FirebaseStorage.instance.ref().child(fileName);
    TaskSnapshot taskSnapshot = await reference.putFile(asset);
    if (taskSnapshot.state == TaskState.success) {
      final String downloadUrl = await taskSnapshot.ref.getDownloadURL();
      print(downloadUrl);
      documentFileUpload(downloadUrl, fileName);
    }
  }

  void documentFileUpload(String downloadUrl, String fileName) {
    var data = {"downloadUrl": downloadUrl, "fileName": fileName};
    final mainReference = FirebaseFirestore.instance
        .collection('patients')
        .doc(patientObject.documentId)
        .collection("Documents");
    mainReference.add(data).then((v) {});
  }
}
