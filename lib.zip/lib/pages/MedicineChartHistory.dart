import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/MedicineChart.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'dart:developer' as developer;

class MedicineChartHistory extends StatefulWidget {
  @override
  _MedicineChartHistoryState createState() => _MedicineChartHistoryState();
}

class _MedicineChartHistoryState extends State<MedicineChartHistory> {
  final PatientData patientData = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: null,
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('patients')
              .doc(patientData.documentId)
              .collection("MedicineChart")
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            return Container(
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 40.0, 0.0, 0),
                    child: DataTable(
                        columns: [
                          DataColumn(label: Text('Date')),
                          DataColumn(label: Text('Doctor')),
                          DataColumn(label: Text('Medicine')),
                          DataColumn(label: Text('Frequency')),
                          DataColumn(label: Text('Instructions')),
                        ],
                        columnSpacing: 10.0,
                        rows: _buildList(snapshot.data.docs))));
          }),
    );
  }

  List<DataRow> _buildList(List<DocumentSnapshot> snapshot) {
    return snapshot.map((data) => _buildListItem(data)).toList();
  }

  DataRow _buildListItem(DocumentSnapshot document) {
    final medicineData = MedicineData.fromJson(document.data(), document.id);
    developer.log('email sent to user ${medicineData.toJson()}');
    return DataRow(cells: [
      DataCell(Text(medicineData.medicineDataDate)),
      DataCell(Text(medicineData.medicineDataDoc)),
      DataCell(Text(medicineData.medicineDataMed)),
      DataCell(Text(medicineData.medicineDataFreq)),
      DataCell(Text(medicineData.medicineDataInstructions)),
    ]);
  }
}
