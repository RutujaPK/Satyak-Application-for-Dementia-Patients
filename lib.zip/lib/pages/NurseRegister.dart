import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:satyak_app/pages/loginPage.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'dart:developer' as developer;

class NurseRegister extends StatefulWidget {
  NurseRegister({Key key, this.registerType}) : super(key: key);
  final String registerType;
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<NurseRegister> {
  final GlobalKey<FormState> _registerFormKey = GlobalKey<FormState>();
  TextEditingController fullNameInputController;
  TextEditingController contactInputController;
  TextEditingController emailInputController;
  TextEditingController addressInputController;
  TextEditingController educationalQualificationInputController;
  TextEditingController dobInputController;
  TextEditingController pwdInputController;
  TextEditingController confirmPwdInputController;
  String maritalStatus = 'Single';
  String bloodGroup = 'O+';
  DateTime currentDate = DateTime.now();

  @override
  initState() {
    fullNameInputController = new TextEditingController();
    contactInputController = new TextEditingController();
    emailInputController = new TextEditingController();
    addressInputController = new TextEditingController();
    educationalQualificationInputController = new TextEditingController();
    dobInputController = new TextEditingController();
    pwdInputController = new TextEditingController();
    confirmPwdInputController = new TextEditingController();
    super.initState();
  }

  String emailValidator(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'Email format is invalid';
    } else {
      return null;
    }
  }

  String pwdValidator(String value) {
    if (value.length < 8) {
      return 'Password must be longer than 8 characters';
    } else {
      return null;
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dobInputController.text = date;
      });
  }

  @override
  Widget build(BuildContext context) {
    developer.log('log me******************** ', name: widget.registerType);
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(children: [
            Container(
              height: 1300,
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Container(
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(0.0, 0.0, 0.0, 20.0),
                        child: Text(
                          " Nurse Registration Form",
                          style: TextStyle(
                              fontSize: 23,
                              color: Colors.teal[600],
                              fontWeight: FontWeight.w500),
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "ID",
                          hintText: "001",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "Full Name",
                          hintText: " First       Middle       Surname",
                        ),
                        controller: fullNameInputController,
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                          controller: contactInputController,
                          decoration: InputDecoration(
                            labelText: "Contact Details",
                            hintText: "XXXXXXXXXX",
                          ),
                          validator: (value) {
                            if (value.length < 10) {
                              return "Please enter a valid phone no.";
                            }
                          }),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                          decoration: InputDecoration(
                            labelText: "Email",
                            hintText: "abc@gmail.com",
                          ),
                          controller: emailInputController,
                          keyboardType: TextInputType.emailAddress,
                          validator: emailValidator),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        controller: addressInputController,
                        decoration: InputDecoration(
                          labelText: "Address",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "Designation",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        controller: educationalQualificationInputController,
                        decoration: InputDecoration(
                          labelText: "Educational Qualifications",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        readOnly: true,
                        onTap: () {
                          // Below line stops keyboard from appearing
                          FocusScope.of(context).requestFocus(new FocusNode());

                          // Show Date Picker Here
                          _selectDate(context);
                        },
                        controller: dobInputController,
                        decoration: InputDecoration(
                          labelText: "Date of Birth",
                          hintText: "DD/MM/YYY",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        decoration: InputDecoration(
                          labelText: "Age",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      DropdownButton<String>(
                        value: maritalStatus,
                        icon: const Icon(Icons.keyboard_arrow_down),
                        iconSize: 24,
                        elevation: 16,
                        isExpanded: true,
                        underline: Container(height: 1, color: Colors.black38),
                        onChanged: (String newValue) {
                          setState(() {
                            maritalStatus = newValue;
                          });
                        },
                        items: <String>[
                          'Single',
                          'Married',
                          'Widowed',
                          'Divorced'
                        ].map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      DropdownButton<String>(
                        value: bloodGroup,
                        icon: const Icon(Icons.keyboard_arrow_down),
                        iconSize: 24,
                        elevation: 16,
                        isExpanded: true,
                        underline: Container(height: 1, color: Colors.black38),
                        onChanged: (String newValue) {
                          setState(() {
                            bloodGroup = newValue;
                          });
                        },
                        items: <String>[
                          'A+',
                          'A-',
                          'B+',
                          'B-',
                          'AB+',
                          'AB-',
                          'O+',
                          'O-',
                          "Unknown"
                        ].map<DropdownMenuItem<String>>((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        obscureText: true,
                        controller: pwdInputController,
                        validator: pwdValidator,
                        decoration: InputDecoration(
                          labelText: "Create Password",
                          hintText: "**********",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      TextFormField(
                        obscureText: true,
                        controller: confirmPwdInputController,
                        validator: pwdValidator,
                        decoration: InputDecoration(
                          labelText: "Re-enter Password",
                          hintText: "**********",
                        ),
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      SizedBox(
                        height: 20.0,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(5.0),
                        child: CupertinoButton(
                            color: Colors.teal[400],
                            borderRadius: BorderRadius.circular(50.0),
                            child: Text(
                              "      Register      ",
                              style: TextStyle(fontSize: 20),
                            ),
                            onPressed: () {
                              if (_registerFormKey.currentState.validate()) {
                                if (pwdInputController.text ==
                                    confirmPwdInputController.text) {
                                  FirebaseAuth.instance
                                      .createUserWithEmailAndPassword(
                                          email: emailInputController.text,
                                          password: pwdInputController.text)
                                      .then((currentUser) => FirebaseFirestore
                                          .instance
                                          .collection("users")
                                          .doc(currentUser.user.uid)
                                          .set({
                                            "uid": currentUser.user.uid,
                                            "fullname":
                                                fullNameInputController.text,
                                            "contact":
                                                contactInputController.text,
                                            "email": emailInputController.text,
                                            "address":
                                                addressInputController.text,
                                            "educationalQualification":
                                                educationalQualificationInputController
                                                    .text,
                                            "dateOfBirth": currentDate,
                                            "maritalStatus": maritalStatus,
                                            "bloodGroup": bloodGroup,
                                            "registrationType":
                                                widget.registerType
                                          })
                                          .then((result) => {
                                                Navigator.push(
                                                    context,
                                                    CupertinoPageRoute(
                                                        builder: (context) =>
                                                            LoginPage())),
                                                fullNameInputController.clear(),
                                                contactInputController.clear(),
                                                emailInputController.clear(),
                                                addressInputController.clear(),
                                                educationalQualificationInputController
                                                    .clear(),
                                                dobInputController.clear(),
                                                pwdInputController.clear(),
                                                confirmPwdInputController
                                                    .clear(),
                                                maritalStatus = 'Single',
                                                bloodGroup = 'O+',
                                                currentDate = DateTime.now()
                                              })
                                          .catchError((err) => print(err)))
                                      .catchError((err) => print(err));
                                } else {
                                  showDialog(
                                      context: context,
                                      builder: (BuildContext context) {
                                        return AlertDialog(
                                          title: Text("Error"),
                                          content: Text(
                                              "The passwords do not match"),
                                          actions: <Widget>[
                                            TextButton(
                                              child: Text("Close"),
                                              onPressed: () {
                                                Navigator.of(context).pop();
                                              },
                                            )
                                          ],
                                        );
                                      });
                                }
                              }
                            }),
                      )
                    ],
                  ),
                ),
              ),
            )
          ]),
        )));
  }
}
