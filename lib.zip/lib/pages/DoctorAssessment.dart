import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satyak_app/models/DoctorAssessment.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/DoctorAssessmentHistory.dart';

class DoctorAssessment extends StatefulWidget {
  @override
  _DoctorAssessmentState createState() => _DoctorAssessmentState();
}

class _DoctorAssessmentState extends State<DoctorAssessment> {
  TextEditingController dateInputController;
  TextEditingController generalInputController;
  TextEditingController systematicInputController;
  TextEditingController fundamentalInputController;
  TextEditingController instrumentalInputController;
  TextEditingController physioInputController;
  TextEditingController socialInputController;
  TextEditingController notesInputController;
  final PatientData patientData = FirebaseData.patientData;
  DateTime currentDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dateInputController.text = date;
      });
  }

  @override
  initState() {
    dateInputController = new TextEditingController();
    generalInputController = new TextEditingController();
    systematicInputController = new TextEditingController();
    fundamentalInputController = new TextEditingController();
    instrumentalInputController = new TextEditingController();
    physioInputController = new TextEditingController();
    socialInputController = new TextEditingController();
    notesInputController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Container(
                        width: MediaQuery.of(context).size.width,
                        child: Padding(
                            padding: const EdgeInsets.all(10.0),
                            child: Container(
                                child: Column(children: [
                              Padding(
                                padding: const EdgeInsets.fromLTRB(
                                    0.0, 0.0, 0.0, 20.0),
                                child: Text(
                                  "Doctor's Assessment",
                                  style: TextStyle(
                                      fontSize: 25,
                                      color: Colors.teal[600],
                                      fontWeight: FontWeight.w500),
                                ),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                readOnly: true,
                                onTap: () {
                                  // Below line stops keyboard from appearing
                                  FocusScope.of(context)
                                      .requestFocus(new FocusNode());

                                  // Show Date Picker Here
                                  _selectDate(context);
                                },
                                controller: dateInputController,
                                decoration: InputDecoration(
                                    labelText: "Date",
                                    hintText: "DD/MM/YYY",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              Text("Physical Assessment",
                                  style: TextStyle(
                                      fontSize: 23, color: Colors.teal[500])),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                controller: generalInputController,
                                decoration: InputDecoration(
                                    labelText: "General",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                controller: systematicInputController,
                                decoration: InputDecoration(
                                    labelText: "Systematic",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              Text("Psychological Assessment",
                                  style: TextStyle(
                                      fontSize: 23, color: Colors.teal[500])),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                controller: fundamentalInputController,
                                decoration: InputDecoration(
                                    labelText: "Fundamental",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                controller: instrumentalInputController,
                                decoration: InputDecoration(
                                    labelText: "Instrumental",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              Text("Physiotherapy",
                                  style: TextStyle(
                                      fontSize: 23, color: Colors.teal[500])),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                controller: physioInputController,
                                decoration: InputDecoration(
                                    labelText: "Observations/Treatment",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              Text("Social Worker",
                                  style: TextStyle(
                                      fontSize: 23, color: Colors.teal[500])),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                controller: socialInputController,
                                decoration: InputDecoration(
                                    labelText: "Observations/Treatment",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              Text("Notes/Instructions",
                                  style: TextStyle(
                                      fontSize: 23, color: Colors.teal[500])),
                              SizedBox(
                                height: 20.0,
                              ),
                              TextFormField(
                                controller: notesInputController,
                                decoration: InputDecoration(
                                    labelText: "Comments",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.zero,
                                    )),
                              ),
                              SizedBox(
                                height: 20.0,
                              ),
                              Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: CupertinoButton(
                                      color: Colors.teal[400],
                                      borderRadius: BorderRadius.circular(50.0),
                                      child: Text(
                                        "         Save         ",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                      onPressed: () {
                                        saveDoctorAssessmentData();
                                      })),
                              SizedBox(
                                height: 40.0,
                              ),
                              Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: CupertinoButton(
                                      color: Colors.teal[400],
                                      borderRadius: BorderRadius.circular(50.0),
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            15.0, 0.0, 15.0, 0.0),
                                        child: Text(
                                          "View History",
                                          style: TextStyle(fontSize: 20),
                                        ),
                                      ),
                                      onPressed: () {
                                        Navigator.push(
                                            context,
                                            CupertinoPageRoute(
                                                builder: (context) =>
                                                    DoctorAssessmentHistory()));
                                      }))
                            ]))))
                  ],
                ))));
  }

  void saveDoctorAssessmentData() {
    DoctorAssessmentData doctorAssessment = new DoctorAssessmentData(
        doctorAssessmentDate: dateInputController.text,
        doctorAssessmentGeneral: generalInputController.text,
        doctorAssessmentSystematic: systematicInputController.text,
        doctorAssessmentFundamental: fundamentalInputController.text,
        doctorAssessmentInstrumental: instrumentalInputController.text,
        doctorAssessmentPhysio: physioInputController.text,
        doctorAssessmentSocial: socialInputController.text,
        doctorAssessmentNotes: notesInputController.text);

    FirebaseFirestore.instance
        .collection('patients')
        .doc(patientData.documentId)
        .collection("DoctorAssessment")
        .add(doctorAssessment.toJson())
        .then((data) =>
            {print("Doctor assement data added ${doctorAssessment.toJson()}")})
        .catchError((err) => print(err));
  }
}
