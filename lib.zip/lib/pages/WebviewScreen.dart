import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'dart:io';
class WebviewScreen extends StatefulWidget {
  WebviewScreen({Key key, this.fileData}) : super(key: key);
  final QueryDocumentSnapshot fileData;

  @override
  WebViewExampleState createState() => WebViewExampleState();
}

class WebViewExampleState extends State<WebviewScreen> {
  var fileUrl = "";
  // double progress = 0;
  // InAppWebViewController webViewController;
  // InAppWebViewGroupOptions options = InAppWebViewGroupOptions(
  //     crossPlatform: InAppWebViewOptions(
  //       useShouldOverrideUrlLoading: true,
  //       mediaPlaybackRequiresUserGesture: false,
  //     ),
  //     android: AndroidInAppWebViewOptions(
  //       useHybridComposition: true,
  //     ),
  //     ios: IOSInAppWebViewOptions(
  //       allowsInlineMediaPlayback: true,
  //     ));

  @override
  void initState() {
    super.initState();
    // Enable hybrid composition.
    if (Platform.isAndroid) WebView.platform = SurfaceAndroidWebView();
    this.fileUrl = widget.fileData["downloadUrl"];
    // if (widget.fileData["fileName"].toString().contains(".pdf")) {
    //   this.fileUrl = "https://docs.google.com/viewer?url=" +
    //       widget.fileData["downloadUrl"];
    // }
  }

  @override
  Widget build(BuildContext context) {
    return WebView(
      initialUrl: fileUrl,
    );
    // return MaterialApp(
    //   home: Scaffold(
    //     appBar: AppBar(
    //       title: const Text('InAppWebView Example'),
    //     ),
    //     body: Container(
    //       child: Column(children: <Widget>[
    //         Container(
    //           padding: EdgeInsets.all(20.0),
    //           child: Text("CURRENT URL\n$fileUrl"),
    //         ),
    //         Container(
    //             padding: EdgeInsets.all(10.0),
    //             child: progress < 1.0
    //                 ? LinearProgressIndicator(value: progress)
    //                 : Container()),
    //         Expanded(
    //           child: Container(
    //             margin: const EdgeInsets.all(10.0),
    //             decoration:
    //                 BoxDecoration(border: Border.all(color: Colors.blueAccent)),
    //             child: InAppWebView(
    //               initialUrlRequest: URLRequest(url: Uri.parse(fileUrl)),
    //               initialOptions: options,
    //             ),
    //           ),
    //         ),
    //       ]),
    //     ),
    //   ),
    // );
  }
}
