import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/PatientReg3.dart';

class PatientReg2 extends StatefulWidget {
  @override
  _PatientReg2State createState() => _PatientReg2State();
}

class _PatientReg2State extends State<PatientReg2> {
  TextEditingController guardianNameController;
  TextEditingController guardianRelationWithPatientController;
  TextEditingController patientNameController;
  TextEditingController guardianDobController;
  TextEditingController guardianAgeController;
  TextEditingController guardianAddressController;
  TextEditingController guardianContactDetailsController;
  TextEditingController guardianEmailController;
  DateTime currentDate = DateTime.now();

  @override
  initState() {
    guardianNameController = new TextEditingController();
    guardianRelationWithPatientController = new TextEditingController();
    patientNameController = new TextEditingController();
    guardianDobController = new TextEditingController();
    guardianAgeController = new TextEditingController();
    guardianAddressController = new TextEditingController();
    guardianContactDetailsController = new TextEditingController();
    guardianEmailController = new TextEditingController();
    super.initState();
  }

  // Default Radio Button Selected Item When App Starts.
  String guardianGenderValue = 'Male';

  // Group Value for Radio Button.
  int genderId = 1;
  String guardianMaritalStatus = 'Single';

  String emailValidator(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'Email format is invalid';
    } else {
      return null;
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        guardianDobController.text = date;
      });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "B. Guardian Details Form",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: guardianNameController,
                              decoration: InputDecoration(
                                labelText: "Name",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: guardianRelationWithPatientController,
                              decoration: InputDecoration(
                                labelText: "Relationship with the Patient",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Column(children: <Widget>[
                              Text("Gender"),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Radio(
                                    value: 1,
                                    groupValue: genderId,
                                    onChanged: (val) {
                                      setState(() {
                                        guardianGenderValue = 'Male';
                                        genderId = 1;
                                      });
                                    },
                                  ),
                                  Text('Male'),
                                  Radio(
                                    value: 2,
                                    groupValue: genderId,
                                    onChanged: (val) {
                                      setState(() {
                                        guardianGenderValue = 'Female';
                                        genderId = 2;
                                      });
                                    },
                                  ),
                                  Text(
                                    'Female',
                                  ),
                                  Radio(
                                    value: 3,
                                    groupValue: genderId,
                                    onChanged: (val) {
                                      setState(() {
                                        guardianGenderValue = 'Other';
                                        genderId = 3;
                                      });
                                    },
                                  ),
                                  Text('Other'),
                                ],
                              )
                            ]),
                            SizedBox(
                              height: 20.0,
                            ),
                            Text('Marital Status'),
                            DropdownButton<String>(
                              value: guardianMaritalStatus,
                              icon: const Icon(Icons.keyboard_arrow_down),
                              iconSize: 24,
                              elevation: 16,
                              isExpanded: true,
                              underline:
                                  Container(height: 1, color: Colors.black38),
                              onChanged: (String newValue) {
                                setState(() {
                                  guardianMaritalStatus = newValue;
                                });
                              },
                              items: <String>[
                                'Single',
                                'Married',
                                'Widowed',
                                'Divorced'
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              onTap: () {
                                // Below line stops keyboard from appearing
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());
                                // Show Date Picker Here
                                _selectDate(context);
                              },
                              controller: guardianDobController,
                              decoration: InputDecoration(
                                labelText: "Date of Birth",
                                hintText: "DD/MM/YYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: guardianAgeController,
                              decoration: InputDecoration(
                                labelText: "Age",
                                // hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: guardianAddressController,
                              decoration: InputDecoration(
                                labelText: "Address",
                                //hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: guardianContactDetailsController,
                              validator: (value) {
                                if (value.length < 10) {
                                  return "Please enter a valid phone no.";
                                }
                              },
                              decoration: InputDecoration(
                                labelText: "Contact Details",
                                hintText: "+91 XXXXXXXXXX",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: guardianEmailController,
                              keyboardType: TextInputType.emailAddress,
                              validator: emailValidator,
                              decoration: InputDecoration(
                                labelText: "Email",
                                hintText: "abc@gmail.com",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                              padding: const EdgeInsets.all(20.0),
                              child: CupertinoButton(
                                  color: Colors.teal[400],
                                  borderRadius: BorderRadius.circular(50.0),
                                  child: Text(
                                    "         Next         ",
                                    style: TextStyle(fontSize: 20),
                                  ),
                                  onPressed: () {
                                    var patientData = PatientData.instance;
                                    patientData.guardianName = guardianNameController.text;
                                    patientData.guardianRelationWithPatient = guardianRelationWithPatientController.text;
                                    patientData.guardianGender = guardianGenderValue;
                                    patientData.guardianMaritalStatus = guardianMaritalStatus;
                                    patientData.guardianAge = guardianAgeController.text;
                                    patientData.guardianAddress = guardianAddressController.text;
                                    patientData.guardianContactDetails = guardianContactDetailsController.text;
                                    patientData.guardianEmail = guardianEmailController.text;
                                    Navigator.push(
                                        context,
                                        CupertinoPageRoute(
                                            builder: (context) =>
                                                PatientReg3()));
                                  }),
                            )
                          ]))))
                ]))));
  }
}
