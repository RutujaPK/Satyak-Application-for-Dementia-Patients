import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/DietChart.dart';
import 'package:satyak_app/models/DoctorAssessment.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/MedicineChart.dart';
import 'package:satyak_app/models/NurseAssessment.dart';
import 'package:satyak_app/models/PatientData.dart';

class MedicalReport extends StatefulWidget {
  @override
  _MedicalReportState createState() => _MedicalReportState();
}

class _MedicalReportState extends State<MedicalReport> {
  final PatientData patientObject = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: Column(children: [
          Text("Nurse Assessment", style: TextStyle(fontSize: 25)),
          Flexible(
              child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('patients')
                      .doc(patientObject.documentId)
                      .collection("NurseAssessment")
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    return ListView(
                      shrinkWrap: false,
                      children: snapshot.data.docs.map((nurseData) {
                        final nurseAssessmentData =
                            NurseAssessmentData.fromJson(
                                nurseData.data(), nurseData.id);
                        print(
                            "${nurseAssessmentData.nurseAssessmentDate} /////////");
                        return Card(
                          margin: const EdgeInsets.all(10.0),
                          child: ListTile(
                            title: Text(
                                "Date : ${nurseAssessmentData.nurseAssessmentDate} \n"
                                "Weight : ${nurseAssessmentData.nurseAssessmentWeight}\n"
                                "Pulse : ${nurseAssessmentData.nurseAssessmentPulse}\n"
                                "BloodPressure : ${nurseAssessmentData.nurseAssessmentBloodPressure}"),
                          ),
                        );
                      }).toList(),
                    );
                  })),
          Text("Doctor Assessment", style: TextStyle(fontSize: 25)),
          Expanded(
              child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('patients')
                      .doc(patientObject.documentId)
                      .collection("DoctorAssessment")
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    return ListView(
                      children: snapshot.data.docs.map((snapshot) {
                        final doctorAssessment = DoctorAssessmentData.fromJson(
                            snapshot.data(), snapshot.id);
                        return Card(
                          margin: const EdgeInsets.all(10.0),
                          child: ListTile(
                            title: Text(
                                "Date : ${doctorAssessment.doctorAssessmentDate} \n"
                                "Physical Assessment\n"
                                "General : ${doctorAssessment.doctorAssessmentGeneral}\n"
                                "Systematic : ${doctorAssessment.doctorAssessmentSystematic}\n"
                                "Psychological Assessment\n"
                                "Fundamental : ${doctorAssessment.doctorAssessmentFundamental}\n"
                                "Instrumental : ${doctorAssessment.doctorAssessmentInstrumental}\n"
                                "Physiotherapy Observations : ${doctorAssessment.doctorAssessmentPhysio}\n"
                                "Social  Observations : ${doctorAssessment.doctorAssessmentSocial}\n"
                                "Notes : ${doctorAssessment.doctorAssessmentNotes}\n"),
                          ),
                        );
                      }).toList(),
                    );
                  })),
          Text("Medicine Chart", style: TextStyle(fontSize: 25)),
          Expanded(
              child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('patients')
                      .doc(patientObject.documentId)
                      .collection("MedicineChart")
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    return ListView(
                      children: snapshot.data.docs.map((document) {
                        final medicineData = MedicineData.fromJson(document.data(), document.id);
                        return Card(
                          margin: const EdgeInsets.all(10.0),
                          child: ListTile(
                            title: Text(
                                "Date : ${medicineData.medicineDataDate} \n"
                                    "Doctor Name : ${medicineData.medicineDataDoc}\n"
                                    "Medicines : ${medicineData.medicineDataMed}\n"
                                    "Medicine Frequency : ${medicineData.medicineDataFreq}\n"
                                    "Instructions : ${medicineData.medicineDataInstructions}"),
                          ),
                        );
                      }).toList(),
                    );
                  })),
          Text("Diet Chart", style: TextStyle(fontSize: 25)),
          Expanded(
              child: StreamBuilder(
                  stream: FirebaseFirestore.instance
                      .collection('patients')
                      .doc(patientObject.documentId)
                      .collection("DietChart")
                      .snapshots(),
                  builder: (BuildContext context,
                      AsyncSnapshot<QuerySnapshot> snapshot) {
                    if (!snapshot.hasData) {
                      return Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    return ListView(
                      children: snapshot.data.docs.map((document) {
                        final dietData = DietData.fromJson(document.data(), document.id);
                        return Card(
                          margin: const EdgeInsets.all(10.0),
                          child: ListTile(
                            title: Text(
                                "Date : ${dietData.dietDataDate} \n"
                                    "Oral Intake : \n${dietData.dietDataOral}\n"
                                    "Fluid Intake: \n${dietData.dietDataFluid}\n"
                                    "Motion :\n${dietData.dietDataMotion}\n"
                                    "Side Effects/Observations : \n${dietData.dietDataObservations}"
                                    "Instructions : \n${dietData.dietDataInstructions}"),
                          ),
                        );
                      }).toList(),
                    );
                  })),
        ]));
  }
}
