import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:satyak_app/pages/loginPage.dart';

class ContactUs extends StatefulWidget {
  @override
  _ContactUsState createState() => _ContactUsState();
}

class _ContactUsState extends State<ContactUs> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.teal[100],
      appBar: AppBar(
        backgroundColor: Colors.teal[400],
        elevation: 0.0,
        title: Text(
          "SATYAK",
          style: TextStyle(fontSize: 30.0),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 10.0),
            Container(
                child: Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 60.0, 0.0, 20.0),
              child: Text(
                "Satyak: Assisted Living for Dementia Patients",
                style: TextStyle(
                    fontSize: 30,
                    color: Colors.teal[600],
                    fontWeight: FontWeight.w500),
              ),
            )),
            Container(
              height: MediaQuery.of(context).size.height / 4,
              width: MediaQuery.of(context).size.width,
              child: Lottie.asset("images/Location.json"),
            ),
            Container(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 20.0, 0.0, 20.0),
                child: Text(
                  "Address: 404 Raviraaj Green Clouds Apartments, Lane No. 3, Right Bhusari Colony, Kothrud, Pune - 411038",
                  style: TextStyle(
                      fontSize: 20,
                      color: Colors.teal[1000],
                      fontWeight: FontWeight.w500),
                ),
              ),
            ),
            Container(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(20.0, 20.0, 0.0, 20.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    "Contact: +91 7028033863",
                    style: TextStyle(
                        fontSize: 20,
                        color: Colors.teal[1000],
                        fontWeight: FontWeight.w500),
                  ),
                ),
              ),
            ),
            Container(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10.0, 0.0, 20.0, 0.0),
                child: Align(
                  alignment: Alignment.topLeft,
                  child: TextButton(
                    onPressed: () {},
                    child: Text(
                      "email: rutuja.kajave.rk@gmail.com",
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.teal[1000],
                          fontWeight: FontWeight.w500),
                    ),
                  ),
                ),
              ),
            ),
            SizedBox(height: 90.0),
            Padding(
              padding: const EdgeInsets.all(0.0),
              child: CupertinoButton(
                  color: Colors.teal[400],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Text(
                    "     Go Back to Login     ",
                    style: TextStyle(fontSize: 20),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        CupertinoPageRoute(builder: (context) => LoginPage()));
                  }),
            ),
          ],
        ),
      ),
    );
  }
}
