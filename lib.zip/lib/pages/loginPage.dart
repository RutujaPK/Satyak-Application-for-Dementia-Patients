import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/pages/DoctorLogin.dart';
import 'package:satyak_app/pages/ForgotPass1.dart';
import 'package:satyak_app/pages/GuardianLogin.dart';
import 'package:satyak_app/pages/NurseOtherLogin.dart';
import 'package:satyak_app/pages/SelectUser.dart';
import 'package:satyak_app/pages/ContactUs.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final GlobalKey<FormState> _loginFormKey = GlobalKey<FormState>();
  TextEditingController emailInputController;
  TextEditingController pwdInputController;

  @override
  initState() {
    emailInputController = new TextEditingController();
    pwdInputController = new TextEditingController();
    super.initState();
  }

  String emailValidator(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'Email format is invalid';
    } else {
      return null;
    }
  }

  String pwdValidator(String value) {
    if (value.length < 6) {
      return 'Password must be longer than 6 characters';
    } else {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
          child: Form(
            key: _loginFormKey,
            child: Column(
              children: [
                SizedBox(height: 10.0),
                Container(
                  height: MediaQuery.of(context).size.height / 3,
                  width: MediaQuery.of(context).size.width,
                  child: Lottie.asset("images/Register.json"),
                ),
                Container(
                  child: Center(
                      child: Text(
                    "Login",
                    style: TextStyle(
                        fontSize: 30,
                        color: Colors.teal[600],
                        fontWeight: FontWeight.w500),
                  )),
                ),
                SizedBox(
                  height: 5.0,
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: Container(
                    height: 300,
                    width: double.infinity,
                    child: Card(
                      color: Colors.teal[50],
                      child: Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Column(
                          children: [
                            TextFormField(
                                decoration: InputDecoration(
                                  labelText: "Email",
                                  hintText: "example@gmail.com",
                                  border: OutlineInputBorder(
                                      borderRadius:
                                          BorderRadius.circular(50.0)),
                                ),
                                controller: emailInputController,
                                keyboardType: TextInputType.emailAddress,
                                validator: emailValidator),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              obscureText: true,
                              controller: pwdInputController,
                              validator: pwdValidator,
                              decoration: InputDecoration(
                                labelText: "Password",
                                hintText: "**********",
                                border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(50.0)),
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: TextButton(
                                  onPressed: () {
                                    Navigator.push(
                                        context,
                                        CupertinoPageRoute(
                                            builder: (context) =>
                                                ForgotPass1()));
                                  },
                                  child: Text("Forgot Password ?")),
                            ),
                            CupertinoButton(
                                color: Colors.teal[400],
                                borderRadius: BorderRadius.circular(50.0),
                                child: Text(
                                  "       Submit       ",
                                  style: TextStyle(fontSize: 20),
                                ),
                                onPressed: () {
                                  if (_loginFormKey.currentState.validate()) {
                                    FirebaseAuth.instance
                                        .signInWithEmailAndPassword(
                                            email: emailInputController.text,
                                            password: pwdInputController.text)
                                        .then(
                                            (currentUser) =>
                                                FirebaseFirestore.instance
                                                    .collection("users")
                                                    .doc(currentUser.user.uid)
                                                    .get()
                                                    .then(
                                                        (DocumentSnapshot result) =>
                                                            {
                                                              FirebaseData.currentUserId = currentUser.user.uid,
                                                              FirebaseData.userData = result,
                                                             Navigator.of(context).pop(),
                                                              if (result.get("registrationType") == "InHouseDoctor")
                                                                {
                                                                  Navigator.pushReplacement(
                                                                      context,
                                                                      CupertinoPageRoute(
                                                                          builder: (context) => DoctorLogin(
                                                                              currentUserId: currentUser.user.uid,
                                                                              userData: result)))
                                                                }
                                                              else if ((result.get("registrationType") == "Nurse") ||
                                                                  (result.get(
                                                                          "registrationType") ==
                                                                      "VisitorDoctor"))
                                                                {
                                                                  Navigator.pushReplacement(
                                                                      context,
                                                                      CupertinoPageRoute(
                                                                          builder: (context) => NurseOtherLogin(
                                                                              currentUserId: currentUser.user.uid,
                                                                              userData: result)))
                                                                }
                                                              else
                                                                {
                                                                  Navigator.pushReplacement(
                                                                      context,
                                                                      CupertinoPageRoute(
                                                                          builder: (context) => GuardianLogin(
                                                                              currentUserId: currentUser.user.uid,
                                                                              userData: result)))
                                                                }
                                                            })
                                                    .catchError(
                                                        (err) => print(err)))
                                        .catchError((err) => print(err));
                                  }
                                })
                          ],
                        ),
                      ),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(25.0)),
                      elevation: 10.0,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(90.0, 0.0, 0.0, 10.0),
                  child: Container(
                      child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Align(
                        alignment: Alignment.bottomLeft,
                        child: Text(
                          "New User ?",
                          style: TextStyle(
                              fontSize: 17,
                              color: Colors.blue[500],
                              fontWeight: FontWeight.w500),
                          textAlign: TextAlign.start,
                        ),
                      ),
                      Align(
                        alignment: Alignment.bottomRight,
                        child: TextButton(
                            onPressed: () {
                              Navigator.push(
                                  context,
                                  CupertinoPageRoute(
                                      builder: (context) => SelectUser()));
                            },
                            child: Text(
                              "Register",
                              style: TextStyle(fontSize: 17),
                            )),
                      ),
                      SizedBox(
                        height: 10.0,
                      ),
                    ],
                  )),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: CupertinoButton(
                      color: Colors.teal[400],
                      borderRadius: BorderRadius.circular(50.0),
                      child: Text(
                        "   Contact Us   ",
                        style: TextStyle(fontSize: 20),
                      ),
                      onPressed: () {
                        Navigator.push(
                            context,
                            CupertinoPageRoute(
                                builder: (context) => ContactUs()));
                      }),
                )
              ],
            ),
          ),
        )); //form
  }
}
