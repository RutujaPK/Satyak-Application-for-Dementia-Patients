import 'dart:convert';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/DoctorLogin.dart';
import 'dart:developer' as developer;

class PatientReg5 extends StatefulWidget {
  @override
  _PatientReg5State createState() => _PatientReg5State();
}

class _PatientReg5State extends State<PatientReg5> {
  TextEditingController patientPresentHistoryController;
  TextEditingController patientSignificantPastHistoryController;
  TextEditingController patientFamilyHistoryController;
  TextEditingController patientPremorbidPersonalityController;
  TextEditingController patientCoMorbidPersonalityController;
  TextEditingController patientOccupationalHistoryController;
  TextEditingController patientMaritalHistoryController;
  TextEditingController patientEducationalQualificationsController;
  var patientData = PatientData.instance;

  @override
  initState() {
    patientPresentHistoryController = new TextEditingController();
    patientSignificantPastHistoryController = new TextEditingController();
    patientFamilyHistoryController = new TextEditingController();
    patientPremorbidPersonalityController = new TextEditingController();
    patientCoMorbidPersonalityController = new TextEditingController();
    patientOccupationalHistoryController = new TextEditingController();
    patientMaritalHistoryController = new TextEditingController();
    patientEducationalQualificationsController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "E. Patient History",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientPresentHistoryController,
                              decoration: InputDecoration(
                                  labelText: "Present History",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller:
                                  patientSignificantPastHistoryController,
                              decoration: InputDecoration(
                                  labelText: "Significant Past History",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientFamilyHistoryController,
                              decoration: InputDecoration(
                                  labelText: "Family History",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientPremorbidPersonalityController,
                              decoration: InputDecoration(
                                  labelText: "Premorbid Personality",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientCoMorbidPersonalityController,
                              decoration: InputDecoration(
                                  labelText: "Co-morbid Medical History",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientOccupationalHistoryController,
                              decoration: InputDecoration(
                                  labelText: "Occupational History",
                                  //hintText: "DD/MM/YYYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientMaritalHistoryController,
                              decoration: InputDecoration(
                                  labelText: "Marital History",
                                  // hintText: "DD/MM/YYYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller:
                                  patientEducationalQualificationsController,
                              decoration: InputDecoration(
                                  labelText: "Educational Qualifications",
                                  //hintText: "DD/MM/YYYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(20.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Text(
                                      "       Submit       ",
                                      style: TextStyle(fontSize: 20),
                                    ),
                                    onPressed: () {
                                      patientData.presentHistory =
                                          patientPresentHistoryController.text;
                                      patientData.significantPastHistory =
                                          patientSignificantPastHistoryController
                                              .text;
                                      patientData.familyHistory =
                                          patientFamilyHistoryController.text;
                                      patientData.premorbidPersonalityHistory =
                                          patientPremorbidPersonalityController
                                              .text;
                                      patientData.coMorbidPersonality =
                                          patientCoMorbidPersonalityController
                                              .text;
                                      patientData.occupationalHistory =
                                          patientOccupationalHistoryController
                                              .text;
                                      patientData.maritalHistory =
                                          patientMaritalHistoryController.text;
                                      patientData.educationalQualifications =
                                          patientEducationalQualificationsController
                                              .text;
                                      addPatient();
                                    }))
                          ]))))
                ]))));
  }

  Future<void> addPatient() {
    // Call the user's CollectionReference to add a new user
    CollectionReference users =
        FirebaseFirestore.instance.collection('patients');
    return users
        .add(patientData.toJson())
        .then((value) => {
              print(
                  "************* patient Data  Added ********** ${patientData.toJson()}"),
              Navigator.push(context,
                  CupertinoPageRoute(builder: (context) => DoctorLogin()))
            })
        .catchError((error) => print("Failed to add user: $error"));
  }
}
