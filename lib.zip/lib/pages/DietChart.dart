import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satyak_app/models/DietChart.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/DietChartHistory.dart';

class DietChart extends StatefulWidget {
  @override
  _DietChartState createState() => _DietChartState();
}

class _DietChartState extends State<DietChart> {
  TextEditingController dateInputController;
  TextEditingController oralInputController;
  TextEditingController fluidInputController;
  TextEditingController motionInputController;
  TextEditingController observationInputController;
  TextEditingController instructionInputController;
  final PatientData patientData = FirebaseData.patientData;
  DateTime currentDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dateInputController.text = date;
      });
  }

  @override
  initState() {
    dateInputController = new TextEditingController();
    oralInputController = new TextEditingController();
    fluidInputController = new TextEditingController();
    motionInputController = new TextEditingController();
    observationInputController = new TextEditingController();
    instructionInputController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "Diet Chart",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              onTap: () {
                                // Below line stops keyboard from appearing
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());

                                // Show Date Picker Here
                                _selectDate(context);
                              },
                              controller: dateInputController,
                              decoration: InputDecoration(
                                  labelText: "Date",
                                  hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: oralInputController,
                              decoration: InputDecoration(
                                  labelText: "Oral Intake",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: fluidInputController,
                              decoration: InputDecoration(
                                  labelText: "Fluid Intake",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: motionInputController,
                              decoration: InputDecoration(
                                  labelText: "Motion",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: observationInputController,
                              decoration: InputDecoration(
                                  labelText: "Side-effects/Observations",
                                  //hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: instructionInputController,
                              decoration: InputDecoration(
                                  labelText: "Comments/Instructions",
                                  hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 40.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Text(
                                      "         Save        ",
                                      style: TextStyle(fontSize: 20),
                                    ),
                                    onPressed: () {
                                      saveDietChartData();
                                    })),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0.0, 15.0, 0.0),
                                      child: Text(
                                        "View History",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                    ),
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          CupertinoPageRoute(
                                              builder: (context) =>
                                                  DietChartHistory()));
                                    }))
                          ]))))
                ]))));
  }

  void saveDietChartData() {
    DietData dietData = new DietData(
        dietDataDate: dateInputController.text,
        dietDataOral: oralInputController.text,
        dietDataFluid: fluidInputController.text,
        dietDataMotion: motionInputController.text,
        dietDataObservations: observationInputController.text,
        dietDataInstructions: instructionInputController.text);

    FirebaseFirestore.instance
        .collection('patients')
        .doc(patientData.documentId)
        .collection("DietChart")
        .add(dietData.toJson())
        .then((data) => {print("Diet data added ${dietData.toJson()}")})
        .catchError((err) => print(err));
  }
}
