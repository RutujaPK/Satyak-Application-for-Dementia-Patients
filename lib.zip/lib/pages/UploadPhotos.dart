import 'dart:io';
import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';

class UploadPhotos extends StatefulWidget {
  @override
  _UploadPhotosState createState() => _UploadPhotosState();
}

class _UploadPhotosState extends State<UploadPhotos> {
  final PatientData patientObject = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      height: 1000,
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "Upload Photos",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            Align(
                              alignment: Alignment.bottomCenter,
                              child: Padding(
                                  padding: const EdgeInsets.all(5.0),
                                  child: CupertinoButton(
                                      color: Colors.teal[400],
                                      borderRadius: BorderRadius.circular(50.0),
                                      child: Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            15.0, 0.0, 15.0, 0.0),
                                        child: Text(
                                          " Upload Photos ",
                                          style: TextStyle(fontSize: 20),
                                        ),
                                      ),
                                      onPressed: () {
                                        //Navigator.push(
                                        //  context,
                                        //CupertinoPageRoute(
                                        //  builder: (context) =>
                                        //    DoctorLogin()));
                                        getPdfAndUpload();
                                      })),
                            )
                          ]))))
                ]))));
  }

  Future getPdfAndUpload() async {
    // var rng = new Random();
    // String randomName = "";
    // for (var i = 0; i < 20; i++) {
    //   print(rng.nextInt(100));
    //   randomName += rng.nextInt(100).toString();
    // }
    FilePickerResult result = await FilePicker.platform.pickFiles();

    if (result != null) {
      PlatformFile platformFile = result.files.single;
      File file = File(platformFile.path);
      // String fileName = '${randomName}.pdf';
      // print(fileName);
      // print('${file.readAsBytesSync()}');
      savePdf(file, platformFile.name);
    } else {
      // User canceled the picker
    }
  }

  Future savePdf(File asset, String fileName) async {
    Reference reference = FirebaseStorage.instance.ref().child(fileName);
    TaskSnapshot taskSnapshot = await reference.putFile(asset);
    if (taskSnapshot.state == TaskState.success) {
      final String downloadUrl = await taskSnapshot.ref.getDownloadURL();
      print(downloadUrl);
      documentFileUpload(downloadUrl, fileName);
    }
  }

  void documentFileUpload(String downloadUrl, String fileName) {
    var data = {"downloadUrl": downloadUrl, "fileName": fileName};
    final mainReference = FirebaseFirestore.instance
        .collection('patients')
        .doc(patientObject.documentId)
        .collection("Documents");
    mainReference.add(data).then((v) {});
  }
}
