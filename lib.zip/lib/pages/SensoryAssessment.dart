import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satyak_app/models/SensoryAssessment.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/SensoryAssessmentHistory.dart';

class SensoryAssessment extends StatefulWidget {
  @override
  _SensoryAssessmentState createState() => _SensoryAssessmentState();
}

class _SensoryAssessmentState extends State<SensoryAssessment> {
  TextEditingController dateInputController;
  TextEditingController ques1InputController;
  TextEditingController ques2InputController;
  TextEditingController ques3InputController;
  TextEditingController ques4InputController;
  final PatientData patientData = FirebaseData.patientData;
  DateTime currentDate = DateTime.now();

  Future<void> _selectDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dateInputController.text = date;
      });
  }

  @override
  initState() {
    dateInputController = new TextEditingController();
    ques1InputController = new TextEditingController();
    ques2InputController = new TextEditingController();
    ques3InputController = new TextEditingController();
    ques3InputController = new TextEditingController();
    ques4InputController = new TextEditingController();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "Sensory Assessment",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              onTap: () {
                                // Below line stops keyboard from appearing
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());

                                // Show Date Picker Here
                                _selectDate(context);
                              },
                              controller: dateInputController,
                              decoration: InputDecoration(
                                  labelText: "Date",
                                  hintText: "DD/MM/YYY",
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.zero,
                                  )),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Text(
                              "___________________________________________\n\nAssessment Scaling:\n1 - Adequate\n2 - Mildly Impaired \n3 - Moderately Impaired\n4 - Highly/Severly Impaired\n___________________________________________",
                              style: TextStyle(fontSize: 15),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Text(
                              "1. How well is the person able to express in their own language?",
                              style: TextStyle(fontSize: 17),
                            ),
                            TextFormField(
                              controller: ques1InputController,
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            Text(
                              "2. How well is the person able to understand verbal information content?",
                              style: TextStyle(fontSize: 17),
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            TextFormField(
                              controller: ques2InputController,
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            Text(
                              "3. How well is the person able to see in adequate light and with glasses,if any?",
                              style: TextStyle(fontSize: 17),
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            TextFormField(
                              controller: ques3InputController,
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            Text(
                              "4. How well is the person able to hear with hearing appliances,if any?",
                              style: TextStyle(fontSize: 17),
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            TextFormField(
                              controller: ques4InputController,
                            ),
                            SizedBox(
                              height: 10.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(10.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Text(
                                      "         Save         ",
                                      style: TextStyle(fontSize: 20),
                                    ),
                                    onPressed: () {
                                      saveSensoryData();
                                    })),
                            SizedBox(
                              height: 10.0,
                            ),
                            Padding(
                                padding: const EdgeInsets.all(5.0),
                                child: CupertinoButton(
                                    color: Colors.teal[400],
                                    borderRadius: BorderRadius.circular(50.0),
                                    child: Padding(
                                      padding: const EdgeInsets.fromLTRB(
                                          15.0, 0.0, 15.0, 0.0),
                                      child: Text(
                                        "View History",
                                        style: TextStyle(fontSize: 20),
                                      ),
                                    ),
                                    onPressed: () {
                                      Navigator.push(
                                          context,
                                          CupertinoPageRoute(
                                              builder: (context) =>
                                                  SensoryAssessmentHistory()));
                                    }))
                          ]))))
                ]))));
  }

  void saveSensoryData() {
    SensoryData sensoryData = new SensoryData(
      sensoryDataDate: dateInputController.text,
      sensoryDataQues1: ques1InputController.text,
      sensoryDataQues2: ques2InputController.text,
      sensoryDataQues3: ques3InputController.text,
      sensoryDataQues4: ques4InputController.text,
    );

    FirebaseFirestore.instance
        .collection('patients')
        .doc(patientData.documentId)
        .collection("SensoryAssessment")
        .add(sensoryData.toJson())
        .then((data) =>
            {
              print("Sensory Assement data added ${sensoryData.toJson()}")})
        .catchError((err) => print(err));
  }
}
