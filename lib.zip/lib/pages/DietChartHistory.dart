import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/DietChart.dart';
import 'package:satyak_app/models/PatientData.dart';

class DietChartHistory extends StatefulWidget {
  @override
  _DietChartHistoryState createState() => _DietChartHistoryState();
}

class _DietChartHistoryState extends State<DietChartHistory> {
  final PatientData patientData = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: null,
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('patients')
              .doc(patientData.documentId)
              .collection("DietChart")
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            return Container(
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 40.0, 0.0, 0),
                    child: DataTable(
                        columns: [
                          DataColumn(label: Text('Date')),
                          DataColumn(label: Text('Oral')),
                          DataColumn(label: Text('Fluid')),
                          DataColumn(label: Text('Motion')),
                          DataColumn(label: Text('Observations')),
                          DataColumn(label: Text('Instructions')),
                        ],
                        columnSpacing: 10.0,
                        rows: _buildList(snapshot.data.docs))));
          }),
    );
  }

  List<DataRow> _buildList(List<DocumentSnapshot> snapshot) {
    return snapshot.map((data) => _buildListItem(data)).toList();
  }

  DataRow _buildListItem(DocumentSnapshot document) {
    final dietData = DietData.fromJson(document.data(), document.id);

    return DataRow(cells: [
      DataCell(Text(dietData.dietDataDate)),
      DataCell(Text(dietData.dietDataOral)),
      DataCell(Text(dietData.dietDataFluid)),
      DataCell(Text(dietData.dietDataMotion)),
      DataCell(Text(dietData.dietDataObservations)),
      DataCell(Text(dietData.dietDataInstructions)),
    ]);
  }
}
