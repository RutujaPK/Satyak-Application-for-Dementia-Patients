import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/pages/UploadPhotos.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/PatientDashboard.dart';

class NurseOtherLogin extends StatefulWidget {
  NurseOtherLogin({Key key, this.currentUserId, this.userData})
      : super(key: key);
  final String currentUserId;
  final DocumentSnapshot userData;

  @override
  _NurseOtherLoginState createState() => _NurseOtherLoginState();
}

class _NurseOtherLoginState extends State<NurseOtherLogin> {
  TextEditingController patientHealthNumberSearchController;
  TextEditingController patientNameSearchController;

  @override
  initState() {
    patientHealthNumberSearchController = new TextEditingController();
    patientNameSearchController =  new TextEditingController();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          SizedBox(height: 10.0),
          Center(
            child: Container(
                child: Padding(
              padding: const EdgeInsets.fromLTRB(20.0, 40.0, 20.0, 20.0),
              child: Text(
                "Search Patient:",
                style: TextStyle(
                    fontSize: 25,
                    color: Colors.teal[600],
                    fontWeight: FontWeight.w400),
              ),
            )),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextFormField(
              controller: patientHealthNumberSearchController,
              decoration: InputDecoration(
                labelText: "Patient Health Number (PHN)",
                hintText: "001",
              ),
            ),
          ),
          SizedBox(
            height: 20.0,
          ),
          Padding(
            padding: const EdgeInsets.all(0.0),
            child: CupertinoButton(
                color: Colors.teal[400],
                borderRadius: BorderRadius.circular(50.0),
                child: Text(
                  "      Search      ",
                  style: TextStyle(fontSize: 20),
                ),
                onPressed: () {
                  getPatientDataPHN(patientHealthNumberSearchController.text);
                }),
          ),
          SizedBox(height: 20.0),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextFormField(
              controller: patientNameSearchController,
              decoration: InputDecoration(
                labelText: "Patient Name",
              ),
            ),
          ),
          SizedBox(
            height: 40.0,
          ),
          Padding(
            padding: const EdgeInsets.all(0.0),
            child: CupertinoButton(
                color: Colors.teal[400],
                borderRadius: BorderRadius.circular(50.0),
                child: Text(
                  "      Search      ",
                  style: TextStyle(fontSize: 20),
                ),
                onPressed: () {
                  getPatientDataName(patientNameSearchController.text);
                }),
          ),
          SizedBox(
            height: 200,
          ),
          Padding(
            padding: const EdgeInsets.all(0.0),
            child: CupertinoButton(
                color: Colors.teal[400],
                borderRadius: BorderRadius.circular(50.0),
                child: Text(
                  "Upload Photos",
                  style: TextStyle(fontSize: 20),
                ),
                onPressed: () {
                  Navigator.push(context,
                      CupertinoPageRoute(builder: (context) => UploadPhotos()));
                }),
          )
        ])));
  }
  void getPatientDataPHN(String patientHealthNumber) {
    if (patientHealthNumber.isNotEmpty) {
      FirebaseFirestore.instance
          .collection('patients')
          .where('patientHealthNumber', isEqualTo: patientHealthNumber)
          .limit(1)
          .get()
          .then((querySnapshot) {
        querySnapshot.docs.forEach((result) {
          print("############# ${result.id}");
          patientHealthNumberSearchController.clear();
          print(
              "&&&&&&&&&&&&&&&& ${PatientData.fromJson(result.data(), result.id).educationalQualifications}");
          FirebaseData.patientData =
              PatientData.fromJson(result.data(), result.id);
          Navigator.push(context,
              CupertinoPageRoute(builder: (context) => PatientDashboard()));
        });
      });
    }
  }

  void getPatientDataName(String patientName) {
    print("############# ${patientName}");
    if(patientName.isNotEmpty) {
      FirebaseFirestore.instance
          .collection('patients')
          .where('patientName', isEqualTo: patientName.toUpperCase())
          .limit(1)
          .get()
          .then((querySnapshot) {
        querySnapshot.docs.forEach((result) {
          print("############# ${result.id}");
          print(
              "&&&&&&&&&&&&&&&& ${PatientData
                  .fromJson(result.data(), result.id)
                  .educationalQualifications}");
          FirebaseData.patientData =
              PatientData.fromJson(result.data(), result.id);
          patientNameSearchController.clear();
          Navigator.push(context,
              CupertinoPageRoute(builder: (context) => PatientDashboard()));
        });
      });
    }
  }
}
