import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/DoctorAssessment.dart';
import 'package:satyak_app/models/PatientData.dart';

class DoctorAssessmentHistory extends StatefulWidget {
  @override
  _DoctorAssessmentHistoryState createState() =>
      _DoctorAssessmentHistoryState();
}

class _DoctorAssessmentHistoryState extends State<DoctorAssessmentHistory> {
  final PatientData patientData = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: null,
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('patients')
              .doc(patientData.documentId)
              .collection("DoctorAssessment")
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            return Container(
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 40.0, 0.0, 0),
                    child: DataTable(
                        columns: [
                          DataColumn(label: Text('Date')),
                          DataColumn(label: Text('General')),
                          DataColumn(label: Text('Systematic')),
                          DataColumn(label: Text('Fundamental')),
                          DataColumn(label: Text('Instrumental')),
                          DataColumn(label: Text('Physio')),
                          DataColumn(label: Text('Social')),
                          DataColumn(label: Text('Notes')),
                        ],
                        columnSpacing: 10.0,
                        rows: _buildList(snapshot.data.docs))));
          }),
    );
  }

  List<DataRow> _buildList(List<DocumentSnapshot> snapshot) {
    return snapshot.map((data) => _buildListItem(data)).toList();
  }

  DataRow _buildListItem(DocumentSnapshot document) {
    final doctorAssessmentData =
        DoctorAssessmentData.fromJson(document.data(), document.id);

    return DataRow(cells: [
      DataCell(Text(doctorAssessmentData.doctorAssessmentDate)),
      DataCell(Text(doctorAssessmentData.doctorAssessmentGeneral)),
      DataCell(Text(doctorAssessmentData.doctorAssessmentSystematic)),
      DataCell(Text(doctorAssessmentData.doctorAssessmentFundamental)),
      DataCell(Text(doctorAssessmentData.doctorAssessmentInstrumental)),
      DataCell(Text(doctorAssessmentData.doctorAssessmentPhysio)),
      DataCell(Text(doctorAssessmentData.doctorAssessmentSocial)),
      DataCell(Text(doctorAssessmentData.doctorAssessmentNotes)),
    ]);
  }
}
