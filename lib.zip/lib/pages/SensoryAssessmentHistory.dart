import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/SensoryAssessment.dart';
import 'package:satyak_app/models/PatientData.dart';

class SensoryAssessmentHistory extends StatefulWidget {
  @override
  _SensoryAssessmentHistoryState createState() =>
      _SensoryAssessmentHistoryState();
}

class _SensoryAssessmentHistoryState extends State<SensoryAssessmentHistory> {
  final PatientData patientData = FirebaseData.patientData;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: null,
      body: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('patients')
              .doc(patientData.documentId)
              .collection("SensoryAssessment")
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (!snapshot.hasData) {
              return Center(
                child: CircularProgressIndicator(),
              );
            }
            return Container(
                child: Padding(
                    padding: const EdgeInsets.fromLTRB(0, 40.0, 0.0, 0),
                    child: DataTable(
                        columns: [
                          DataColumn(label: Text('Date')),
                          DataColumn(label: Text('Ques1')),
                          DataColumn(label: Text('Ques2')),
                          DataColumn(label: Text('Ques3')),
                          DataColumn(label: Text('Ques4')),
                        ],
                        columnSpacing: 10.0,
                        rows: _buildList(snapshot.data.docs))));
          }),
    );
  }

  List<DataRow> _buildList(List<DocumentSnapshot> snapshot) {
    return snapshot.map((data) => _buildListItem(data)).toList();
  }

  DataRow _buildListItem(DocumentSnapshot document) {
    final sensoryData = SensoryData.fromJson(document.data(), document.id);

    return DataRow(cells: [
      DataCell(Text(sensoryData.sensoryDataDate)),
      DataCell(Text(sensoryData.sensoryDataQues1)),
      DataCell(Text(sensoryData.sensoryDataQues2)),
      DataCell(Text(sensoryData.sensoryDataQues3)),
      DataCell(Text(sensoryData.sensoryDataQues4)),
    ]);
  }
}
