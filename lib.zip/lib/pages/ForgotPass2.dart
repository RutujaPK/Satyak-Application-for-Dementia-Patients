import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
//import 'package:lottie/lottie.dart';
import 'package:satyak_app/pages/LoginPage.dart';

class ForgotPass2 extends StatefulWidget {
  @override
  _ForgotPass2State createState() => _ForgotPass2State();
}

class _ForgotPass2State extends State<ForgotPass2> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          SizedBox(height: 50.0),
          Container(
            child: Center(
                child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Text(
                "Enter a new Password: ",
                style: TextStyle(
                    fontSize: 25,
                    color: Colors.teal[600],
                    fontWeight: FontWeight.w500),
              ),
            )),
          ),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextFormField(
              decoration: InputDecoration(
                hintText: "**********",
              ),
            ),
          ),
          SizedBox(height: 50.0),
          SizedBox(height: 50.0),
          Container(
              child: Padding(
            padding: const EdgeInsets.all(0.0),
            child: Text(
              "Re-enter the Password: ",
              style: TextStyle(
                  fontSize: 25,
                  color: Colors.teal[600],
                  fontWeight: FontWeight.w500),
            ),
          )),
          Padding(
            padding: const EdgeInsets.all(20.0),
            child: TextFormField(
              decoration: InputDecoration(
                hintText: "**********",
              ),
            ),
          ),
          SizedBox(height: 50.0),
          CupertinoButton(
              color: Colors.teal[400],
              borderRadius: BorderRadius.circular(50.0),
              child: Text(
                "      Verify      ",
                style: TextStyle(fontSize: 20),
              ),
              onPressed: () {
                Navigator.push(context,
                    CupertinoPageRoute(builder: (context) => LoginPage()));
              }),
        ])));
  }
}
