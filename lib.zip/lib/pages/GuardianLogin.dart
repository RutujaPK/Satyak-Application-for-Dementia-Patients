import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/ContactUs.dart';
import 'package:satyak_app/pages/MedicalReport.dart';
import 'package:satyak_app/pages/PatientPhotos.dart';
import 'package:satyak_app/pages/PhotoGallery.dart';

class GuardianLogin extends StatefulWidget {
  GuardianLogin({Key key, this.currentUserId, this.userData}) : super(key: key);
  final String currentUserId;
  final DocumentSnapshot userData;

  @override
  _NurseOtherLoginState createState() => _NurseOtherLoginState();
}

class _NurseOtherLoginState extends State<GuardianLogin> {
  String patientName = '';
  String patientAge = '';
  String patientHealthNumber = '';

  @override
  initState() {
    print(
        "log me******************** USER DATA ${FirebaseData.userData.data().toString()}");
    print(
        "log me******************** USER DATA ${FirebaseData.userData.get("patientHealthNumber")}");
    getPatientDataPHN(FirebaseData.userData.get("patientHealthNumber"));
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: Align(
              alignment: Alignment.topCenter,
              child: Container(
                child: Image.asset(
                  'images/Rutuja.jpg',
                  height: 300,
                  width: 300,
                ),
              ),
            ),
          ),
          Text(
            patientHealthNumber,
            style: TextStyle(fontSize: 25),
          ),
          Text(
            patientName,
            style: TextStyle(fontSize: 25),
          ),
          Text(
            "Age: $patientAge",
            style: TextStyle(fontSize: 25),
          ),
          SizedBox(
            height: 40,
          ),
          Padding(
              padding: const EdgeInsets.all(10.0),
              child: CupertinoButton(
                  color: Colors.teal[400],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Text(
                    "     Medical Report     ",
                    style: TextStyle(fontSize: 25),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => MedicalReport()));
                  })),
          SizedBox(
            height: 20,
          ),
          Padding(
              padding: const EdgeInsets.all(10.0),
              child: CupertinoButton(
                  color: Colors.teal[400],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Text(
                    "      Photo Gallery      ",
                    style: TextStyle(fontSize: 25),
                  ),
                  onPressed: () {
                    Navigator.push(
                        context,
                        CupertinoPageRoute(
                            builder: (context) => PhotoGallery()));
                  })),
          SizedBox(
            height: 20,
          ),
          Padding(
              padding: const EdgeInsets.all(10.0),
              child: CupertinoButton(
                  color: Colors.teal[400],
                  borderRadius: BorderRadius.circular(50.0),
                  child: Text(
                    "        Contact Us        ",
                    style: TextStyle(fontSize: 25),
                  ),
                  onPressed: () {
                    Navigator.push(context,
                        CupertinoPageRoute(builder: (context) => ContactUs()));
                  })),
        ])));
  }

  void getPatientDataPHN(String patientHealthNumber) {
    if (patientHealthNumber.isNotEmpty) {
      FirebaseFirestore.instance
          .collection('patients')
          .where('patientHealthNumber', isEqualTo: patientHealthNumber)
          .limit(1)
          .get()
          .then((querySnapshot) {
        querySnapshot.docs.forEach((result) {
          print("############# ${result.id}");
          FirebaseData.patientData =
              PatientData.fromJson(result.data(), result.id);
          print("............ ${FirebaseData.patientData.patientName}");
          changeText();
        });
      });
    }
  }

  void changeText() {
    setState(() {
      this.patientName = FirebaseData.patientData.patientName;
      this.patientAge = FirebaseData.patientData.patientAge;
      this.patientHealthNumber = FirebaseData.patientData.patientHealthNumber;
    });

  }
}
