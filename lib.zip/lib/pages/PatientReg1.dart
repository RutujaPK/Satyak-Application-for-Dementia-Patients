import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:satyak_app/models/FirebaseData.dart';
import 'package:satyak_app/models/PatientData.dart';
import 'package:satyak_app/pages/PatientReg2.dart';
import 'dart:developer' as developer;

class PatientReg1 extends StatefulWidget {
  PatientReg1({Key key, this.patientId}) : super(key: key);
  final String patientId;

  @override
  _PatientReg1State createState() => _PatientReg1State();
}

class _PatientReg1State extends State<PatientReg1> {
  TextEditingController dateOfAdmissionController;
  TextEditingController dateOfDischargeController;
  TextEditingController patientNameController;
  TextEditingController patientHealthNumberController;
  TextEditingController patientSexController;
  TextEditingController patientMaritalStatusController;
  TextEditingController patientDobController;
  TextEditingController patientAgeController;
  TextEditingController patientAddressController;
  TextEditingController patientContactDetailsController;
  TextEditingController patientEmailController;
  TextEditingController patientHobbiesController;
  TextEditingController patientDietController;
  TextEditingController patientPremorbidPersonalityController;
  DateTime currentDate = DateTime.now();

  @override
  initState() {
    dateOfAdmissionController = new TextEditingController();
    dateOfDischargeController = new TextEditingController();
    patientNameController = new TextEditingController();
    patientHealthNumberController = new TextEditingController();
    patientSexController = new TextEditingController();
    patientMaritalStatusController = new TextEditingController();
    patientDobController = new TextEditingController();
    patientAgeController = new TextEditingController();
    patientAddressController = new TextEditingController();
    patientContactDetailsController = new TextEditingController();
    patientEmailController = new TextEditingController();
    patientHobbiesController = new TextEditingController();
    patientDietController = new TextEditingController();
    patientPremorbidPersonalityController = new TextEditingController();
    super.initState();
  }

// Default Radio Button Selected Item When App Starts.
  String genderValue = 'Male';

  // Group Value for Radio Button.
  int genderId = 1;
  String maritalStatus = 'Single';

  String emailValidator(String value) {
    Pattern pattern =
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    RegExp regex = new RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'Email format is invalid';
    } else {
      return null;
    }
  }

  Future<void> _selectAdmissionDate(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dateOfAdmissionController.text = date;
      });
  }

  Future<void> _selectDateOfDischarge(BuildContext context) async {
    final DateTime pickedDate = await showDatePicker(
        context: context,
        initialDate: currentDate,
        firstDate: DateTime(1947),
        lastDate: DateTime(2021, 12));
    if (pickedDate != null && pickedDate != currentDate)
      setState(() {
        currentDate = pickedDate;
        var date =
            "${pickedDate.toLocal().day}/${pickedDate.toLocal().month}/${pickedDate.toLocal().year}";
        dateOfDischargeController.text = date;
      });
  }

  @override
  Widget build(BuildContext context) {
    developer.log('log me******************** USER ID',
        name: FirebaseData.currentUserId);
    developer.log('log me******************** USER DATA ',
        name: FirebaseData.userData.data().toString());
    var patientData = PatientData.instance;
    developer.log("*&&& ",name:"******************** ${widget.patientId}");

    return Scaffold(
        resizeToAvoidBottomInset: false,
        backgroundColor: Colors.teal[100],
        appBar: AppBar(
          backgroundColor: Colors.teal[400],
          elevation: 0.0,
          title: Text(
            "SATYAK",
            style: TextStyle(fontSize: 30.0),
          ),
          centerTitle: true,
        ),
        body: SingleChildScrollView(
            child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(children: [
                  Container(
                      width: MediaQuery.of(context).size.width,
                      child: Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Container(
                              child: Column(children: [
                            Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  0.0, 0.0, 0.0, 20.0),
                              child: Text(
                                "A. Patient Registration Form",
                                style: TextStyle(
                                    fontSize: 25,
                                    color: Colors.teal[600],
                                    fontWeight: FontWeight.w500),
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              onTap: () {
                                // Below line stops keyboard from appearing
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());
                                // Show Date Picker Here
                                _selectAdmissionDate(context);
                              },
                              controller: dateOfAdmissionController,
                              decoration: InputDecoration(
                                labelText: "Date of Admission",
                                hintText: "DD/MM/YYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              onTap: () {
                                // Below line stops keyboard from appearing
                                FocusScope.of(context)
                                    .requestFocus(new FocusNode());
                                // Show Date Picker Here
                                _selectDateOfDischarge(context);
                              },
                              controller: dateOfDischargeController,
                              decoration: InputDecoration(
                                labelText: "Date of Discharge",
                                hintText: "DD/MM/YYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientNameController,
                              decoration: InputDecoration(
                                labelText: "Name",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              readOnly: true,
                              initialValue: widget.patientId,
                              decoration: InputDecoration(
                                labelText: "Patient Health Number",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Column(children: <Widget>[
                              Text("Gender"),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: <Widget>[
                                  Radio(
                                    value: 1,
                                    groupValue: genderId,
                                    onChanged: (val) {
                                      setState(() {
                                        genderValue = 'Male';
                                        genderId = 1;
                                      });
                                    },
                                  ),
                                  Text('Male'),
                                  Radio(
                                    value: 2,
                                    groupValue: genderId,
                                    onChanged: (val) {
                                      setState(() {
                                        genderValue = 'Female';
                                        genderId = 2;
                                      });
                                    },
                                  ),
                                  Text(
                                    'Female',
                                  ),
                                  Radio(
                                    value: 3,
                                    groupValue: genderId,
                                    onChanged: (val) {
                                      setState(() {
                                        genderValue = 'Other';
                                        genderId = 3;
                                      });
                                    },
                                  ),
                                  Text('Other'),
                                ],
                              )
                            ]),
                            SizedBox(
                              height: 20.0,
                            ),
                            Text('Marital Status'),
                            DropdownButton<String>(
                              value: maritalStatus,
                              icon: const Icon(Icons.keyboard_arrow_down),
                              iconSize: 24,
                              elevation: 16,
                              isExpanded: true,
                              underline:
                                  Container(height: 1, color: Colors.black38),
                              onChanged: (String newValue) {
                                setState(() {
                                  maritalStatus = newValue;
                                });
                              },
                              items: <String>[
                                'Single',
                                'Married',
                                'Widowed',
                                'Divorced'
                              ].map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(value),
                                );
                              }).toList(),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientDobController,
                              decoration: InputDecoration(
                                labelText: "Date of Birth",
                                hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientAgeController,
                              decoration: InputDecoration(
                                labelText: "Age",
                                // hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientAddressController,
                              decoration: InputDecoration(
                                labelText: "Address",
                                //hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientContactDetailsController,
                              decoration: InputDecoration(
                                labelText: "Contact Details",
                                hintText: "+XXXXXXXXXX",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientEmailController,
                              keyboardType: TextInputType.emailAddress,
                              validator: emailValidator,
                              decoration: InputDecoration(
                                labelText: "Email",
                                hintText: "abc@gmail.com",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientHobbiesController,
                              decoration: InputDecoration(
                                labelText: "Hobbies",
                                // hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientDietController,
                              decoration: InputDecoration(
                                labelText: "Diet",
                                //hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            TextFormField(
                              controller: patientPremorbidPersonalityController,
                              decoration: InputDecoration(
                                labelText: "Premorbid Personality",
                                //hintText: "DD/MM/YYYY",
                              ),
                            ),
                            SizedBox(
                              height: 20.0,
                            ),
                            Padding(
                              padding: const EdgeInsets.all(20.0),
                              child: CupertinoButton(
                                  color: Colors.teal[400],
                                  borderRadius: BorderRadius.circular(50.0),
                                  child: Text(
                                    "         Next         ",
                                    style: TextStyle(fontSize: 20),
                                  ),
                                  onPressed: () {
                                    patientData.dateOfAdmission =
                                        dateOfAdmissionController.text;
                                    patientData.dateOfDischarge =
                                        dateOfDischargeController.text;
                                    patientData.patientName =
                                        patientNameController.text;
                                    patientData.patientHealthNumber =
                                        patientHealthNumberController.text;
                                    patientData.patientGender = genderValue;
                                    patientData.patientMaritalStatus =
                                        maritalStatus;
                                    patientData.patientDob =
                                        patientDobController.text;
                                    patientData.patientAge =
                                        patientAgeController.text;
                                    patientData.patientAddress =
                                        patientAddressController.text;
                                    patientData.patientContactDetails =
                                        patientContactDetailsController.text;
                                    patientData.patientEmail =
                                        patientEmailController.text;
                                    patientData.patientHobbies =
                                        patientHobbiesController.text;
                                    patientData.patientDiet =
                                        patientDietController.text;
                                    patientData.patientPremorbidPersonality =
                                        patientPremorbidPersonalityController
                                            .text;
                                    developer.log(
                                        'log me******************** PatientData',
                                        name: patientData.patientName);
                                    String jsonUser = jsonEncode(PatientData.instance);
                                    print("############# $jsonUser");
                                    Navigator.push(
                                        context,
                                        CupertinoPageRoute(
                                            builder: (context) =>
                                                PatientReg2()));
                                  }),
                            )
                          ]))))
                ]))));
  }
}
