import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';

import 'package:satyak_app/pages/WelcomePage.dart';
//import 'package:satyak_app/pages/HomePage.dart';
//import 'package:satyak_app/pages/HomePage2.dart';
//import 'package:satyak_app/pages/HomePage3.dart';
//import 'package:satyak_app/pages/LoginPage.dart';
//import 'package:satyak_app/pages/ContactUs.dart';
//import 'package:satyak_app/pages/SelectUser.dart';
//import 'package:satyak_app/pages/ForgotPass1.dart';
//import 'package:satyak_app/pages/ForgotPass2.dart';
//import 'package:satyak_app/pages/GuardianRegister.dart';
//import 'package:satyak_app/pages/InHouseDocRegister.dart';
//import 'package:satyak_app/pages/NurseRegister.dart';
//import 'package:satyak_app/pages/VisitDocRegister.dart';
//import 'package:satyak_app/pages/DoctorLogin.dart';
//import 'package:satyak_app/pages/NurseOtherLogin.dart';
//import 'package:satyak_app/pages/GuardianLogin.dart';
//import 'package:satyak_app/pages/PatientReg1.dart';
//import 'package:satyak_app/pages/PatientReg2.dart';
//import 'package:satyak_app/pages/PatientReg3.dart';
//import 'package:satyak_app/pages/PatientReg4.dart';
//import 'package:satyak_app/pages/PatientReg5.dart';
//import 'package:satyak_app/pages/PatientDashboard.dart';
//import 'package:satyak_app/pages/NurseAssessment.dart';
//import 'package:satyak_app/pages/DoctorAssessment.dart';
//import 'package:satyak_app/pages/DailyActivities.dart';
//import 'package:satyak_app/pages/SensoryAssessment.dart';
//import 'package:satyak_app/pages/MedicineChart.dart';
//import 'package:satyak_app/pages/DietChart.dart';
//import 'package:satyak_app/pages/MedicalReport.dart';
//import 'package:satyak_app/pages/PhotoGallery.dart';
//import 'package:satyak_app/pages/PatientPhotos.dart';
//import 'package:satyak_app/pages/UploadPhotos.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}
// void main() {
//   runApp(MyApp());
// }

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: WelcomePage(),
      //home: HomePage(),
      //home: HomePage2(),
      //home: HomePage3(),
      //home: LoginPage(),
      //home: ContactUs(),
      //home: SelectUser(),
      //home: ForgotPass1(),
      //home: ForgotPass2(),
      //home: GuardianRegister(),
      //home: InHouseDocRegister(),
      //home: NurseRegister(),
      //home: VisitDocRegister(),
      //home: DoctorLogin(),
      //home: NurseOtherLogin(),
      //home: GuardianLogin(),
      //home: PatientReg1()
      //home: PatientReg2()
      //home: PatientReg3()
      //home: PatientReg4(),
      //home: PatientReg5()
      //home: PatientDashboard(),
      //home: NurseAssessment(),
      //home: DoctorAssessment(),
      //home: DailyActivities(),
      //home: SensoryAssessment(),
      //home: MedicineChart(),
      //home: DietChart(),
      //home: MedicalReport(),
      //home: PhotoGallery(),
      //home: PatientPhotos()
      //home: UploadPhotos()
    );
  }
}
