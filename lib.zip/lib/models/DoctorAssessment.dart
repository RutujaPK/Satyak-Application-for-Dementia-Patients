class DoctorAssessmentData {
  String doctorAssessmentDate;
  String doctorAssessmentGeneral;
  String doctorAssessmentSystematic;
  String doctorAssessmentFundamental;
  String doctorAssessmentInstrumental;
  String doctorAssessmentPhysio;
  String doctorAssessmentSocial;
  String doctorAssessmentNotes;
  String documentId;

  DoctorAssessmentData({
    this.doctorAssessmentDate,
    this.doctorAssessmentGeneral,
    this.doctorAssessmentSystematic,
    this.doctorAssessmentFundamental,
    this.doctorAssessmentInstrumental,
    this.doctorAssessmentPhysio,
    this.doctorAssessmentSocial,
    this.doctorAssessmentNotes,
  });

  Map<String, dynamic> toJson() => {
        "DoctorAssessmentDate": doctorAssessmentDate,
        "DoctorAssessmentGeneral": doctorAssessmentGeneral,
        "DoctorAssessmentSystematic": doctorAssessmentSystematic,
        "DoctorAssessmentFundamental": doctorAssessmentFundamental,
        "DoctorAssessmentInstrumental": doctorAssessmentInstrumental,
        "DoctorAssessmentPhysio": doctorAssessmentPhysio,
        "DoctorAssessmentSocial": doctorAssessmentSocial,
        "DoctorAssessmentNotes": doctorAssessmentNotes,
      };

  DoctorAssessmentData.fromJson(Map<String, dynamic> json, String documentId) {
    this.documentId = documentId;
    doctorAssessmentDate = json["DoctorAssessmentDate"];
    doctorAssessmentGeneral = json["DoctorAssessmentGeneral"];
    doctorAssessmentSystematic = json["DoctorAssessmentSystematic"];
    doctorAssessmentFundamental = json["DoctorAssessmentFundamental"];
    doctorAssessmentInstrumental = json["DoctorAssessmentInstrumental"];
    doctorAssessmentPhysio = json["DoctorAssessmentPhysio"];
    doctorAssessmentSocial = json["DoctorAssessmentSocial"];
    doctorAssessmentNotes = json["DoctorAssessmentNotes"];
  }
}
