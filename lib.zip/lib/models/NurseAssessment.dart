class NurseAssessmentData {
  String nurseAssessmentDate;
  String nurseAssessmentPulse;
  String nurseAssessmentBloodPressure;
  String nurseAssessmentWeight;
  String documentId;

  NurseAssessmentData(
      {this.nurseAssessmentDate,
      this.nurseAssessmentPulse,
      this.nurseAssessmentBloodPressure,
      this.nurseAssessmentWeight});

  Map<String, dynamic> toJson() => {
        "nurseAssessmentDate": nurseAssessmentDate,
        "nurseAssessmentPulse": nurseAssessmentPulse,
        "nurseAssessmentBloodPressure": nurseAssessmentBloodPressure,
        "nurseAssessmentWeight": nurseAssessmentWeight,
      };

  NurseAssessmentData.fromJson(Map<String, dynamic> json, String documentId) {
    this.documentId = documentId;
    nurseAssessmentDate = json["nurseAssessmentDate"];
    nurseAssessmentPulse = json["nurseAssessmentPulse"];
    nurseAssessmentBloodPressure = json["nurseAssessmentBloodPressure"];
    nurseAssessmentWeight = json["nurseAssessmentWeight"];
  }
}
