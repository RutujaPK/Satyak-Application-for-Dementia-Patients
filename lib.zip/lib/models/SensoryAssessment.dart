class SensoryData {
  String sensoryDataDate;
  String sensoryDataQues1;
  String sensoryDataQues2;
  String sensoryDataQues3;
  String sensoryDataQues4;
  String documentId;

  SensoryData({
    this.sensoryDataDate,
    this.sensoryDataQues1,
    this.sensoryDataQues2,
    this.sensoryDataQues3,
    this.sensoryDataQues4,
  });

  Map<String, dynamic> toJson() => {
        "SensoryDataDate": sensoryDataDate,
        "SensoryDataQues1": sensoryDataQues1,
        "SensoryDataQues2": sensoryDataQues2,
        "SensoryDataQues3": sensoryDataQues3,
        "SensoryDataQues4": sensoryDataQues4,
      };

  SensoryData.fromJson(Map<String, dynamic> json, String documentId) {
    this.documentId = documentId;
    sensoryDataDate = json["SensoryDataDate"];
    sensoryDataQues1 = json["SensoryDataQues1"];
    sensoryDataQues2 = json["SensoryDataQues2"];
    sensoryDataQues3 = json["SensoryDataQues3"];
    sensoryDataQues4 = json["SensoryDataQues4"];
  }
}
