class DietData {
  String dietDataDate;
  String dietDataOral;
  String dietDataFluid;
  String dietDataMotion;
  String dietDataObservations;
  String dietDataInstructions;
  String documentId;

  DietData({
    this.dietDataDate,
    this.dietDataOral,
    this.dietDataFluid,
    this.dietDataMotion,
    this.dietDataObservations,
    this.dietDataInstructions,
  });

  Map<String, dynamic> toJson() => {
        "DietDataDate": dietDataDate,
        "DietDataOral": dietDataOral,
        "DietDataFluid": dietDataFluid,
        "DietDataMotion": dietDataMotion,
        "DietDataObservations": dietDataObservations,
        "DietDataInstructions": dietDataInstructions,
      };

  DietData.fromJson(Map<String, dynamic> json, String documentId) {
    this.documentId = documentId;
    dietDataDate = json["DietDataDate"];
    dietDataOral = json["DietDataOral"];
    dietDataFluid = json["DietDataFluid"];
    dietDataMotion = json["DietDataMotion"];
    dietDataObservations = json["DietDataObservations"];
    dietDataInstructions = json["DietDataInstructions"];
  }
}
