class DailyActData {
  String actDataDate;
  String actDataQues1;
  String actDataQues2;
  String actDataQues3;
  String actDataQues4;
  String documentId;

  DailyActData({
    this.actDataDate,
    this.actDataQues1,
    this.actDataQues2,
    this.actDataQues3,
    this.actDataQues4,
  });

  Map<String, dynamic> toJson() => {
        "DailyActDataDate": actDataDate,
        "DailyActDataQues1": actDataQues1,
        "DailyActDataQues2": actDataQues2,
        "DailyActDataQues3": actDataQues3,
        "DailyActDataQues4": actDataQues4,
      };

  DailyActData.fromJson(Map<String, dynamic> json, String documentId) {
    this.documentId = documentId;
    actDataDate = json["DailyActDataDate"];
    actDataQues1 = json["DailyActDataQues1"];
    actDataQues2 = json["DailyActDataQues2"];
    actDataQues3 = json["DailyActDataQues3"];
    actDataQues4 = json["DailyActDataQues4"];
  }
}
