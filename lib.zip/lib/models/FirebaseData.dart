import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:satyak_app/models/PatientData.dart';

class FirebaseData {

  static String currentUserId;
  static DocumentSnapshot userData;
  static PatientData patientData;
}