class MedicineData {
  String medicineDataDate;
  String medicineDataDoc;
  String medicineDataMed;
  String medicineDataFreq;
  String medicineDataInstructions;
  String documentId;

  MedicineData(
      {this.medicineDataDate,
      this.medicineDataDoc,
      this.medicineDataMed,
      this.medicineDataFreq,
      this.medicineDataInstructions});

  Map<String, dynamic> toJson() => {
        "MedicineDataDate": medicineDataDate,
        "MedicineDataDoc": medicineDataDoc,
        "MedicineDataMed": medicineDataMed,
        "MedicineDataFreq": medicineDataFreq,
        "MedicineDataInstructions": medicineDataInstructions,
      };

  MedicineData.fromJson(Map<String, dynamic> json, String documentId) {
    this.documentId = documentId;
    medicineDataDate = json["MedicineDataDate"];
    medicineDataDoc = json["MedicineDataDoc"];
    medicineDataMed = json["MedicineDataMed"];
    medicineDataFreq = json["MedicineDataFreq"];
    medicineDataInstructions = json["MedicineDataInstructions"];
  }
}
