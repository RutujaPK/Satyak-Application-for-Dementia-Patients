class PatientData {
  //screen 1
  String dateOfAdmission;
  String dateOfDischarge;
  String patientName;
  String patientHealthNumber;
  String patientGender;
  String patientMaritalStatus;
  String patientDob;
  String patientAge;
  String patientAddress;
  String patientContactDetails;
  String patientEmail;
  String patientHobbies;
  String patientDiet;
  String patientPremorbidPersonality;

  //screen 2
  String guardianName;
  String guardianRelationWithPatient;
  String guardianGender;
  String guardianMaritalStatus;
  String guardianDob;
  String guardianAge;
  String guardianAddress;
  String guardianContactDetails;
  String guardianEmail;

  //screen 3
  String applicantGuardianName;
  String applicantRelationWithPatient;
  String applicantPatientIssue;
  String legalGuardianName;
  String legalGuardianRelationWithPatient;
  String applicationDate;
  String applicationLocation;
  String legalGuardianApplicationDate;
  String legalGuardianApplicationLocation;

  //screen 5
  String presentHistory;
  String significantPastHistory;
  String familyHistory;
  String premorbidPersonalityHistory;
  String coMorbidPersonality;
  String occupationalHistory;
  String maritalHistory;
  String educationalQualifications;
  String documentId;

  PatientData.fromJson(Map<String, dynamic> json,String documentId) {
    this.documentId = documentId;
    dateOfAdmission = json["dateOfAdmission"];
    dateOfDischarge = json["dateOfDischarge"];
    patientName = json["patientName"];
    patientHealthNumber = json["patientHealthNumber"];
    patientGender = json["patientGender"];
    patientMaritalStatus = json["patientMaritalStatus"];
    patientDob = json["patientDob"];
    patientAge = json["patientAge"];
    patientAddress = json["patientAddress"];
    patientContactDetails = json["patientContactDetails"];
    patientEmail = json["patientEmail"];
    patientHobbies = json["patientHobbies"];
    patientDiet = json["patientDiet"];
    patientPremorbidPersonality = json["patientPremorbidPersonality"];
    guardianName = json["guardianName"];
    guardianRelationWithPatient = json["guardianRelationWithPatient"];
    guardianGender = json["guardianGender"];
    guardianMaritalStatus = json["guardianMaritalStatus"];
    guardianDob = json["guardianDob"];
    guardianAge = json["guardianAge"];
    guardianAddress = json["guardianAddress"];
    guardianContactDetails = json["guardianContactDetails"];
    guardianEmail = json["guardianEmail"];
    applicantGuardianName = json["applicantGuardianName"];
    applicantRelationWithPatient = json["applicantRelationWithPatient"];
    applicantPatientIssue = json["applicantPatientIssue"];
    legalGuardianName = json["legalGuardianName"];
    legalGuardianRelationWithPatient = json["legalGuardianRelationWithPatient"];
    applicationDate = json["applicationDate"];
    applicationLocation = json["applicationLocation"];
    legalGuardianApplicationDate = json["legalGuardianApplicationDate"];
    legalGuardianApplicationLocation = json["legalGuardianApplicationLocation"];
    presentHistory = json["presentHistory"];
    significantPastHistory = json["significantPastHistory"];
    familyHistory = json["familyHistory"];
    premorbidPersonalityHistory = json["premorbidPersonalityHistory"];
    coMorbidPersonality = json["coMorbidPersonality"];
    occupationalHistory = json["occupationalHistory"];
    maritalHistory = json["maritalHistory"];
    educationalQualifications = json["educationalQualifications"];
  }

  PatientData._privateConstructor();

  static final PatientData _instance = PatientData._privateConstructor();

  static PatientData get instance => _instance;

  Map<String, dynamic> toJson() => {
        "dateOfAdmission": dateOfAdmission,
        "dateOfDischarge": dateOfDischarge,
        "patientName": patientName.toUpperCase(),
        "patientHealthNumber": patientHealthNumber,
        "patientGender": patientGender,
        "patientMaritalStatus": patientMaritalStatus,
        "patientDob": patientDob,
        "patientAge": patientAge,
        "patientAddress": patientAddress,
        "patientContactDetails": patientContactDetails,
        "patientEmail": patientEmail,
        "patientHobbies": patientHobbies,
        "patientDiet": patientDiet,
        "patientPremorbidPersonality": patientPremorbidPersonality,
        "guardianName": guardianName,
        "guardianRelationWithPatient": guardianRelationWithPatient,
        "guardianGender": guardianGender,
        "guardianMaritalStatus": guardianMaritalStatus,
        "guardianDob": guardianDob,
        "guardianAge": guardianAge,
        "guardianAddress": guardianAddress,
        "guardianContactDetails": guardianContactDetails,
        "guardianEmail": guardianEmail,
        "applicantGuardianName": applicantGuardianName,
        "applicantRelationWithPatient": applicantRelationWithPatient,
        "applicantPatientIssue": applicantPatientIssue,
        "legalGuardianName": legalGuardianName,
        "legalGuardianRelationWithPatient": legalGuardianRelationWithPatient,
        "applicationDate": applicationDate,
        "applicationLocation": applicationLocation,
        "legalGuardianApplicationDate": legalGuardianApplicationDate,
        "legalGuardianApplicationLocation": legalGuardianApplicationLocation,
        "presentHistory": presentHistory,
        "significantPastHistory": significantPastHistory,
        "familyHistory": familyHistory,
        "premorbidPersonalityHistory": premorbidPersonalityHistory,
        "coMorbidPersonality": coMorbidPersonality,
        "occupationalHistory": occupationalHistory,
        "maritalHistory": maritalHistory,
        "educationalQualifications": educationalQualifications
      };

  @override
  String toString() {
    return toJson().toString();
  }
}
